select count(*) from bancs_base.ptdm; ----3438

select count(*) from bancs_raw.ptdm; ----3438

select count(*) from bancs_base.ptdm where upper(trim(current_flg)) ='Y'; --- 3438

select count(*) from bancs_base.ptdm where upper(trim(current_flg)) !='Y'; -- 0

select count(*) from cap_mi_test.v_payments_to_dim ;  -- 3438


select count(*) from cap_mi_test.v_payments_to_dim where business_date is null; -- 0

select 
payee_bancs_account_number, payment_to_transcation_date , payment_to_transcation_number ,
count(*) 
from v_payments_to_dim
group by 
payee_bancs_account_number, payment_to_transcation_date , payment_to_transcation_number 
having count(*) >1  ----18


select count(*) from payments_to_fact;  --- 3422----


-----------------
select count(*) from bancs_base.ptxn; ----51567

select count(*) from bancs_raw.ptxn;  -- 51567

select count(*) from bancs_base.ptxn where upper(trim(current_flg)) ='Y'; --- 50835

select count(*) from bancs_base.ptxn where upper(trim(current_flg)) !='Y'; --- 732

select count(*) from cap_mi_test.v_payments_from_dim ;  ---50835

select count(*) from cap_mi_test.v_payments_from_dim where business_date is null;  -- 0

select payer_bancs_account_number, payment_from_transaction_date, payment_from_transaction_number,
count(*) 
from cap_mi_test.v_payments_from_dim
group by payer_bancs_account_number, payment_from_transaction_date, payment_from_transaction_number
having count(*) > 1;   ---0


select payer_bancs_account_number, payment_from_transaction_date, payment_from_transaction_number,
count(*) 
from cap_mi_test.payments_from_fact
group by payer_bancs_account_number, payment_from_transaction_date, payment_from_transaction_number
having count(*) > 1;   ---0

select count(*) from cap_mi_test.payments_from_fact;  ---  50835


