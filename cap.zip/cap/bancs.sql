CREATE DATABASE IF NOT EXISTS ${hivevar:dbName} COMMENT 'BANCS raw database' LOCATION '${hivevar:hdfsDIR}';

CREATE DATABASE IF NOT EXISTS bancs_raw COMMENT 'BANCS raw database' LOCATION '/user/hive/warehouse/bancs/raw.db';

CREATE DATABASE IF NOT EXISTS bancs_base COMMENT 'BANCS base database' LOCATION '/user/hive/warehouse/bancs/base.db';


 
CREATE EXTERNAL TABLE IF NOT EXISTS bancs_raw.glif
(
 
 ROW_WID           			bigint ,
 KEY_1             			string ,
 SOC               			string ,
 BRCH              			string ,
 FCY_CODE          			string ,
 GL_CLASS_CODE     			string ,
 DESCRIPTION       			string ,
 POSTING_IND       			string ,
 TRANS_DATE        			string ,
 LCY_AMT           			double ,
 FCY_AMT           			double ,
 REVERSAL_CODE     			string ,
 REVERSAL_DATE     			string ,
 GLIF_REFERENCES   			string ,
 SOURCE_APPLN      			string ,
 PS_JOURNAL_ID     			string ,
 PS_JOURNAL_NBR    			bigint ,
 CNTL_CENTRE       			string ,
 LCY_NPV_AMT       			double ,
 FCY_NPV_AMT       			double ,
 PROMO_NO          			string ,
 ISLAMIC_BANK      			string ,
 HOME_BRCH         			string ,
 ACCT_TYPE         			string ,
 TELLER_NO         			string ,
 MISC_REFERENCE    			string ,
 DATASOURCE_NUM_ID 			bigint ,
 EFFECTIVE_FROM_DT 			string ,
 EFFECTIVE_TO_DT   			string ,
 CHANGE_FLG        			string ,
 CURRENT_FLG       			string ,
 LOAD_DT           			string ,
 ETL_PROC_WID      			bigint 
 )
PARTITIONED BY (LOAD_DATE  STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/user/hive/warehouse/bancs/raw.db/glif';
LOCATION '${hivevar:hdfsDIR}/s_postn';
