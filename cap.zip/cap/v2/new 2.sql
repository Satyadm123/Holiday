SELECT 
(DATEDIFF(ENDDATE, STARTDATE) +1) – (2* ( ((YEAR(ENDDATE) – YEAR(STARTDATE)) * 52) + (WEEKOFYEAR(ENDDATE)-WEEKOFYEAR(STARTDATE)) ) ) 
– CASE WHEN FROM_UNIXTIME(UNIX_TIMESTAMP(ENDDATE, ‘YY-MM-DD’), ‘EEE’) = ‘SUN’ THEN 1 ELSE 0 END
– CASE WHEN FROM_UNIXTIME(UNIX_TIMESTAMP(STARTDATE, ‘YY-MM-DD’), ‘EEE’)=’SAT’ THEN 1 ELSE 0 END
FROM 



SELECT 
(DATEDIFF('2019-01-14', '2019-01-04') ) 
- ( 2 * (( (YEAR('2019-01-14') - YEAR('2019-01-04')) * 52) + (WEEKOFYEAR('2019-01-14') - WEEKOFYEAR('2019-01-04') )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2019-01-14', 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end ,
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2019-01-04', 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end ,
- select count(*) from tem


SELECT 
(DATEDIFF('2019-01-04', '2018-12-27') ) 
- ( 2 * (( (YEAR('2019-01-04') - YEAR('2018-12-27')) * 52) + (WEEKOFYEAR('2019-01-04') - WEEKOFYEAR('2018-12-27') )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2019-01-04', 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end ,
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2018-12-27', 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end

SELECT 
(DATEDIFF('2019-01-14', '2019-01-04') ) 
- ( 2 * (( (YEAR('2019-01-14') - YEAR('2019-01-04')) * 52) + (WEEKOFYEAR('2019-01-14') - WEEKOFYEAR('2019-01-04') )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2019-01-14', 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2019-01-04', 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 

-count(*) from test_date where cast('2019-01-04' as date)<=h_date and cast('2019-01-14' as date) >=h_date



SELECT 
(DATEDIFF('2019-04-22', '2019-04-02') ) 
- ( 2 * (( (YEAR('2019-04-22') - YEAR('2019-04-02')) * 52) + (WEEKOFYEAR('2019-04-22') - WEEKOFYEAR('2019-04-02') )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2019-04-22', 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2019-04-02', 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
- count(*) from test_date where cast('2019-01-04' as date)<=h_date and cast('2019-01-14' as date) >=h_date


SELECT 
(DATEDIFF(set_fact.sr_end_date, set_fact.sr_start_date) ) 
- ( 2 * (( (YEAR(set_fact.sr_end_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.sr_end_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_end_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
- count(*) from non_working_day where cast(set_fact.sr_start_date as date)<=holiday and cast(set_fact.sr_end_date as date) >=holiday
from 
cap_mi_test.tmp_srv_fact set_fact


(DATEDIFF(set_fact.business_date, set_fact.sr_start_date) ) 
- ( 2 * (( (YEAR(set_fact.business_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.business_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.business_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
- count(*) from non_working_day where cast(set_fact.sr_start_date as date)<=holiday and cast(set_fact.business_date as date) >=holiday


SELECT 
(DATEDIFF('2019-04-22', '2019-04-02') ) 
- ( 2 * (( (YEAR('2019-04-22') - YEAR('2019-04-02')) * 52) + (WEEKOFYEAR('2019-04-22') - WEEKOFYEAR('2019-04-02') )) ) 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2019-04-22', 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end  
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2019-04-02', 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
- case when cast('2019-01-04' as date) <= cast('2019-01-08' as date) and cast('2019-01-14' as date) >= cast('2019-01-08' as date)
      then 1 else 0 end 





