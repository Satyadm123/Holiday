select r.from_acct,r.to_acct,r.business_date,r.amount,
g.glif_references,g.business_date,substring(g.key_1,29,9),g.lcy_amt,
g1.glif_references,g1.business_date,substring(g1.key_1,29,9),g1.lcy_amt,

from rect r 
inner join glif g
on r.from_acct= g.glif_references   AND r.business_date = g.business_date   --and abs(r.amount) = abs(g.lcy_amt) 
inner join glif g1

on r.to_acct= g1.glif_references   AND r.business_date = g1.business_date 
and substring(g.key_1,29,9) = substring(g1.key_1,29,9) --and abs(r.amount) = abs(g1.lcy_amt) 




select count(*) from raw_cms2012_bancs.rect; --- 19525

select count(*) from base_cms2012_bancs.rect; --- 19525

select count(*) from glif; --- 2851358

select count(*) from v_gl_dim; --- 2851358

select count(*) from ddb_cms2012.bank_transfer_fact; --- 2851368


select count(*) from v_gl_dim v
left join v_gl_class_dim c on v.gl_code = c.gl_code; -- 2851358

select count(*) from v_gl_dim v
left join (select distinct gl_code from v_gl_class_dim) c on v.gl_code = c.gl_code; --2851358


select count(*) from v_gl_class_dim; --113

select count(distinct gl_code) from v_gl_class_dim; --- 113


select count(*) from v_gl_dim v
left join (select distinct gl_code from v_gl_class_dim) c on v.gl_code = c.gl_code
left join  tmp_asset_dim a on 
concat(upper(trim(v.soc)), upper(trim(v.glif_references)))=upper(trim(a.key_1)); --- -- 2851368

select count(*) from v_gl_dim v
left join (select distinct gl_code from v_gl_class_dim) c on v.gl_code = c.gl_code
left join (select distinct key_1 from  tmp_asset_dim ) a on 
concat(upper(trim(v.soc)), upper(trim(v.glif_references)))=upper(trim(a.key_1)); --- -- 2851358

select c.gl_code , count(*) from v_gl_class_dim c
group by c.gl_code
having count(*) > 1; --- gl_code = 11211

select * from v_gl_class_dim where gl_code ='11211';



