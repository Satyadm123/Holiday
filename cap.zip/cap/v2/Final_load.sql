SET hive.exec.dynamic.partition = true;  
SET hive.exec.dynamic.partition.mode = nonstrict; 
set hive.exec.max.dynamic.partitions = 20000; 
set hive.exec.max.dynamic.partitions.pernode = 10000;
set mapreduce.map.memory.mb = 4000;

drop table cap_mi_test.tmp_srv_fact;
create table cap_mi_test.tmp_srv_fact as 
select
sr_id	,	
sr_number	,	
sr_process	,	
sr_area	,	
sr_sub_area	,	
sr_start_date	,	
sr_start_time	,	
sr_end_date	,	
sr_end_time	,	
sr_reason	,	
sr_due_date	,	
sr_resolution_code	,	
sr_status	,	
sr_sub_status	,	
sr_next_action_due_date	,	
sr_source	,	
sr_case_id	,	
sr_owner_employee_id	,	
sr_created_date	,	
sr_updated_date	,	
sr_version_number	,	
cast(sr_x_uniq_ref_num as int) sr_x_uniq_ref_num ,
v_service_request_dim.load_date, 
v_service_request_dim.business_date,
sr_status_id	,	
sr_status_name	,	
sr_status_val	,	
sr_status_start_date	,	
sr_status_end_date	,	
sr_status_created_date	,	
sr_status_update_date	,	
sr_status_version_number	,	
sr_status_batch_number	,
sr_sub_status_id	,	
sr_sub_status_name	,	
sr_sub_status_val	,	
sr_sub_status_start_date	,	
sr_sub_status_end_date	,	
sr_sub_status_created_date	,	
sr_sub_status_update_date	,	
sr_sub_status_version_number	,	
sr_sub_status_batch_number	,
contact_id	,	
contact_scin	,	
contact_created_date	,	
contact_update_date	,	
contact_version_number	,
case_id	,	
case_number	,	
case_master_case_number	,	
case_created_date	,	
case_update_date	,	
case_version_number	,
org.name employer_name ,
org.x_ern_arn employer_reference_number,
org_pos.region ,
org_pos.segment ,
org_pos.sub_segment ,
org_pos.division ,
org_pos.sub_divn ,
org_pos.team ,
case when (upper(trim(sr_status)) ='CLOSED' and sr_due_date is not null and sr_end_date is not null) then 1 else 0 end  as sr_event_clearance_ind	,	
case when (sr_version_number = 0 and sr_due_date is not null and to_date(sr_created_date) = to_date(sr_start_date)) then 1 else 0 end as sr_event_intake_ind	,	
case when (upper(trim(sr_status)) !='CLOSED' and sr_end_date is  null ) then 1 else 0 end  as sr_event_work_on_hand_ind	,
case when 
(case when (upper(trim(sr_status)) !='CLOSED' and sr_end_date is  null ) then 1 else 0 end )= '1'
and 
(case when (sr_version_number = 0 and sr_due_date is not null and to_date(sr_created_date) = to_date(sr_start_date)) then 1 else 0 end ) = '0'
then 1 else 0 end as sr_event_work_on_hand_brought_forward_ind

from cap_mi_test.v_service_request_dim 
inner join cap_mi_test.v_service_request_status_dim
on v_service_request_dim.sr_id =v_service_request_status_dim.sr_status_id
inner join cap_mi_test.v_service_request_sub_status_dim
on v_service_request_dim.sr_id =v_service_request_sub_status_dim.sr_sub_status_id

left outer join cap_mi_2012.v_contact_dim
on sr_owner_employee_id = v_contact_dim.contact_id
left outer join siebel_base.s_postn pos 
on pos.row_id = v_contact_dim.contact_position and trim(pos.current_flg)='Y'
left outer join cap_mi_2012.v_case_dim
on sr_case_id=v_case_dim.case_id
left outer join siebel_base.s_org_ext org 
on pos.ou_id =org.row_id and trim(org.current_flg)='Y'

left outer join siebel_base.s_org_pos_h org_pos
on cast(sr_x_uniq_ref_num as int) = org_pos.position_wid

where  v_service_request_dim.business_date = ${hivevar:dateToRun}
and v_service_request_status_dim.business_date = ${hivevar:dateToRun}
and v_service_request_sub_status_dim.business_date = ${hivevar:dateToRun};







insert into cap_mi_test.service_request_event_fact_v2 partition(load_date,business_date)

Select
set_fact.`sr_id` , 
set_fact.`sr_number` , 
set_fact.`sr_process` , 
set_fact.`sr_area` , 
set_fact.`sr_sub_area` , 
set_fact.`sr_start_date` , 
set_fact.`sr_start_time` , 
set_fact.`sr_end_date` , 
set_fact.`sr_end_time` , 
set_fact.`sr_reason` , 
set_fact.`sr_due_date` , 
set_fact.`sr_resolution_code` , 
set_fact.`sr_status` , 
set_fact.`sr_sub_status` , 
set_fact.`sr_next_action_due_date` , 
set_fact.`sr_source` , 
set_fact.`sr_case_id` , 
set_fact.`sr_owner_employee_id` , 
set_fact.`sr_created_date` , 
set_fact.`sr_updated_date` , 
set_fact.`sr_version_number` , 
set_fact.`sr_x_uniq_ref_num` , 
set_fact.`sr_status_id` , 
set_fact.`sr_status_name` , 
set_fact.`sr_status_val` , 
set_fact.`sr_status_start_date` , 
set_fact.`sr_status_end_date` , 
set_fact.`sr_status_created_date` , 
set_fact.`sr_status_update_date` , 
set_fact.`sr_status_version_number` , 
set_fact.`sr_status_batch_number` , 
set_fact.`sr_sub_status_id` , 
set_fact.`sr_sub_status_name` , 
set_fact.`sr_sub_status_val` , 
set_fact.`sr_sub_status_start_date` , 
set_fact.`sr_sub_status_end_date` , 
set_fact.`sr_sub_status_created_date` , 
set_fact.`sr_sub_status_update_date` , 
set_fact.`sr_sub_status_version_number` , 
set_fact.`sr_sub_status_batch_number` , 
set_fact.`contact_id` , 
set_fact.`contact_scin` , 
set_fact.`contact_created_date` , 
set_fact.`contact_update_date` , 
set_fact.`contact_version_number` , 
set_fact.`case_id` , 
set_fact.`case_number` , 
set_fact.`case_master_case_number` , 
set_fact.`case_created_date` , 
set_fact.`case_update_date` , 
set_fact.`case_version_number` , 
set_fact.`employer_name` , 
set_fact.`employer_reference_number` big, 
set_fact.`region` , 
set_fact.`segment` , 
set_fact.`sub_segment` , 
set_fact.`division` , 
set_fact.`sub_divn` , 
set_fact.`team` ,
set_fact.`sr_event_clearance_ind`, 
'0' as sr_event_intake_ind,
'1' as sr_event_work_on_hand_ind,
'1' as sr_event_work_on_hand_brought_forward_ind,

case when set_fact.sr_event_clearance_ind = '1' then datediff(to_date(set_fact.sr_end_date),to_date(set_fact.sr_start_date)) 
else case when set_fact.sr_event_work_on_hand_ind = '1' then datediff(to_date(cast(date_add(to_date(set_fact.business_date) , 1) as string )),to_date(set_fact.sr_start_date)) 
end end as sr_cal_age,

case when set_fact.sr_event_clearance_ind = '1' then datediff(to_date(set_fact.sr_end_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.sr_end_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.sr_end_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_end_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
--- end date ingest

else case when set_fact.sr_event_work_on_hand_ind = '1' then datediff(to_date(set_fact.business_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.business_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.business_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.business_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
-- businee date ingest
end 
end as sr_wor_age,

s.sla,
age.band as band,
age_w.band as wor_band,

case when s.sla is not null
then case when 
set_fact.sr_event_clearance_ind = '1' and  date_add(cast(set_fact.sr_start_date as date),cast(s.sla as int)) >= cast(set_fact.sr_end_date as date) 
then '1' else 0 end end as sr_event_clearance_within_sla_ind,

case when s.sla is not null
then case when 
set_fact.sr_event_clearance_ind = '1' and  date_add(cast(set_fact.sr_start_date as date),cast(s.sla as int)) < cast(set_fact.sr_end_date as date) 
then '1' else 0 end end as sr_event_clearance_outside_sla_ind,

case when s.sla is not null
then case when 
set_fact.sr_event_work_on_hand_ind = '1' and  date_add(cast(set_fact.sr_start_date as date),cast(s.sla as int)) >= date_add(to_date(set_fact.business_date) , 1) 
then '1' else 0 end end as sr_event_woh_within_sla_ind,

case when s.sla is not null
then case when 
set_fact.sr_event_work_on_hand_ind = '1' and  date_add(cast(set_fact.sr_start_date as date),cast(s.sla as int)) < date_add(to_date(set_fact.business_date) , 1) 
then '1' else 0 end end as sr_event_woh_outside_sla_ind,

current_timestamp as processed_time,
set_fact.load_date,
cast(date_add(to_date(set_fact.business_date) , 1) as string )as business_date





From
    (select A.* 
     from 
        (select  f.*, rank() over (partition by f.sr_number order by sr_updated_date desc) as rnk
        from cap_mi_test.service_request_event_fact_v2 f
        WHERE business_date =${hivevar:PrevRunDate} and f.sr_event_clearance_ind != '1'
        ) A 
    where a.rnk = 1
    ) as set_fact
left join
    (select A.* 
    from 
        (select   f.*, rank() over (partition by f.sr_number order by sr_updated_date desc) as rnk
        from cap_mi_test.tmp_srv_fact f
        WHERE business_date =${hivevar:dateToRun}
        ) A 
    where a.rnk = 1
    ) as set_temp
on set_fact.sr_number=set_temp.sr_number
left join sr_sla s on 
set_fact.sr_process = s.process and set_fact.sr_area = s.area and set_fact.sr_sub_area = s.subarea

left join age_band age on upper(trim(cast(cast(nvl(s.sla, -1)  as int) as string))) = upper(trim(cast(age.total_sla as string)))  
left join age_band age_w on upper(trim(cast(cast(nvl(s.sla, '-1')  as int) as string))) = upper(trim(cast(age_w.total_sla as string))) 
where

age.start_day <=
case when set_fact.sr_event_clearance_ind = '1' then datediff(to_date(set_fact.sr_end_date),to_date(set_fact.sr_start_date)) 
else case when set_fact.sr_event_work_on_hand_ind = '1' then datediff(to_date(cast(date_add(to_date(set_fact.business_date) , 1) as string )),to_date(set_fact.sr_start_date)) 
end end  
and age.end_day > case when set_fact.sr_event_clearance_ind = '1' then datediff(to_date(set_fact.sr_end_date),to_date(set_fact.sr_start_date)) 
else case when set_fact.sr_event_work_on_hand_ind = '1' then datediff(to_date(cast(date_add(to_date(set_fact.business_date) , 1) as string )),to_date(set_fact.sr_start_date)) 
end end
and 
age_w.start_day <=
case when set_fact.sr_event_clearance_ind = '1' then 
datediff(to_date(set_fact.sr_end_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.sr_end_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.sr_end_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_end_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
--- end date ingest
else case when set_fact.sr_event_work_on_hand_ind = '1' then 
datediff(to_date(set_fact.business_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.business_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.business_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.business_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
-- businee date ingest

end end  
and age_w.end_day > case when set_fact.sr_event_clearance_ind = '1' then 
datediff(to_date(set_fact.sr_end_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.sr_end_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.sr_end_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_end_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
--- end date ingest
else case when set_fact.sr_event_work_on_hand_ind = '1' then 
datediff(to_date(set_fact.business_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.business_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.business_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.business_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
-- businee date ingest

end end
and set_temp.sr_number is null




union all



Select
set_fact.`sr_id` , 
set_fact.`sr_number` , 
set_fact.`sr_process` , 
set_fact.`sr_area` , 
set_fact.`sr_sub_area` , 
set_fact.`sr_start_date` , 
set_fact.`sr_start_time` , 
set_fact.`sr_end_date` , 
set_fact.`sr_end_time` , 
set_fact.`sr_reason` , 
set_fact.`sr_due_date` , 
set_fact.`sr_resolution_code` , 
set_fact.`sr_status` , 
set_fact.`sr_sub_status` , 
set_fact.`sr_next_action_due_date` , 
set_fact.`sr_source` , 
set_fact.`sr_case_id` , 
set_fact.`sr_owner_employee_id` , 
set_fact.`sr_created_date` , 
set_fact.`sr_updated_date` , 
set_fact.`sr_version_number` , 
set_fact.`sr_x_uniq_ref_num` , 
set_fact.`sr_status_id` , 
set_fact.`sr_status_name` , 
set_fact.`sr_status_val` , 
set_fact.`sr_status_start_date` , 
set_fact.`sr_status_end_date` , 
set_fact.`sr_status_created_date` , 
set_fact.`sr_status_update_date` , 
set_fact.`sr_status_version_number` , 
set_fact.`sr_status_batch_number` , 
set_fact.`sr_sub_status_id` , 
set_fact.`sr_sub_status_name` , 
set_fact.`sr_sub_status_val` , 
set_fact.`sr_sub_status_start_date` , 
set_fact.`sr_sub_status_end_date` , 
set_fact.`sr_sub_status_created_date` , 
set_fact.`sr_sub_status_update_date` , 
set_fact.`sr_sub_status_version_number` , 
set_fact.`sr_sub_status_batch_number` , 
set_fact.`contact_id` , 
set_fact.`contact_scin` , 
set_fact.`contact_created_date` , 
set_fact.`contact_update_date` , 
set_fact.`contact_version_number` , 
set_fact.`case_id` , 
set_fact.`case_number` , 
set_fact.`case_master_case_number` , 
set_fact.`case_created_date` , 
set_fact.`case_update_date` , 
set_fact.`case_version_number` , 
set_fact.`employer_name` , 
set_fact.`employer_reference_number` big, 
set_fact.`region` , 
set_fact.`segment` , 
set_fact.`sub_segment` , 
set_fact.`division` , 
set_fact.`sub_divn` , 
set_fact.`team` ,
set_fact.`sr_event_clearance_ind`, 
set_fact.sr_event_intake_ind,
set_fact.sr_event_work_on_hand_ind,
set_fact.sr_event_work_on_hand_brought_forward_ind,

case when set_fact.sr_event_clearance_ind = '1' then datediff(to_date(set_fact.sr_end_date),to_date(set_fact.sr_start_date)) 
else case when set_fact.sr_event_work_on_hand_ind = '1' then datediff(to_date(set_fact.business_date),to_date(set_fact.sr_start_date)) 
end 
end as sr_cal_age,

case when set_fact.sr_event_clearance_ind = '1' then datediff(to_date(set_fact.sr_end_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.sr_end_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.sr_end_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_end_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
--- end date ingest

else case when set_fact.sr_event_work_on_hand_ind = '1' then datediff(to_date(set_fact.business_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.business_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.business_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.business_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
-- businee date ingest
end 
end as sr_wor_age,

s.sla,

age.band as cal_band,
age_w.band as wor_band,

case when s.sla is not null
then case when 
set_fact.sr_event_clearance_ind = '1' and  date_add(cast(set_fact.sr_start_date as date),cast(s.sla as int)) >= cast(set_fact.sr_end_date as date) 
then '1' else 0 end end
as sr_event_clearance_within_sla_ind,

case when s.sla is not null 
then case when 
set_fact.sr_event_clearance_ind = '1' and  date_add(cast(set_fact.sr_start_date as date),cast(s.sla as int)) < cast(set_fact.sr_end_date as date) 
then '1' else 0 end end 
as sr_event_clearance_outside_sla_ind,

case when s.sla is not null 
then case when
set_fact.sr_event_work_on_hand_ind = '1' and  date_add(cast(set_fact.sr_start_date as date),cast(s.sla as int)) >= cast(set_fact.business_date as date) 
then '1' else 0 end end 
as sr_event_woh_within_sla_ind,

case when s.sla is not null
then case when 
set_fact.sr_event_work_on_hand_ind = '1' and  date_add(cast(set_fact.sr_start_date as date),cast(s.sla as int)) < cast(set_fact.business_date as date) 
then '1' else 0 end end 
as sr_event_woh_outside_sla_ind,
current_timestamp as processed_time,

set_fact.load_date,
set_fact.business_date
from 
cap_mi_test.tmp_srv_fact set_fact
left join sr_sla s on 
set_fact.sr_process = s.process and set_fact.sr_area = s.area and set_fact.sr_sub_area = s.subarea
left join age_band age on upper(trim(cast(cast(nvl(s.sla, '-1')  as int) as string))) = upper(trim(cast(age.total_sla as string))) 
left join age_band age_w on upper(trim(cast(cast(nvl(s.sla, '-1')  as int) as string))) = upper(trim(cast(age_w.total_sla as string))) 
where 
age.start_day <=
case when set_fact.sr_event_clearance_ind = '1' then datediff(to_date(set_fact.sr_end_date),to_date(set_fact.sr_start_date)) 
else case when set_fact.sr_event_work_on_hand_ind = '1' then datediff(to_date(set_fact.business_date),to_date(set_fact.sr_start_date)) 
end end  
and age.end_day > case when set_fact.sr_event_clearance_ind = '1' then datediff(to_date(set_fact.sr_end_date),to_date(set_fact.sr_start_date)) 
else case when set_fact.sr_event_work_on_hand_ind = '1' then datediff(to_date(set_fact.business_date),to_date(set_fact.sr_start_date)) 
end end
and 
age_w.start_day <=
case when set_fact.sr_event_clearance_ind = '1' then 
datediff(to_date(set_fact.sr_end_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.sr_end_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.sr_end_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_end_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
--- end date ingest
else case when set_fact.sr_event_work_on_hand_ind = '1' then 
datediff(to_date(set_fact.business_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.business_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.business_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.business_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
-- businee date ingest

end end  
and age_w.end_day > case when set_fact.sr_event_clearance_ind = '1' then 
datediff(to_date(set_fact.sr_end_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.sr_end_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.sr_end_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_end_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
--- end date ingest
else case when set_fact.sr_event_work_on_hand_ind = '1' then 
datediff(to_date(set_fact.business_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.business_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.business_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.business_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
-- businee date ingest

end end

