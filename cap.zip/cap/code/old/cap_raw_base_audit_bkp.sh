echo "drop table if exists audit_base_tmp_${1};" >${1}_ctl_${2}.hql
echo "drop table if exists audit_raw_tmp_${1};" >>${1}_ctl_${2}.hql

echo "\n" >>${1}_ctl_${2}.hql

echo "create temporary table audit_raw_tmp_${1} as
select '${1}' as table_name,load_date, substr(trim(last_upd),0,10) as  business_date ,count(*) as raw_cnt from siebel_raw.${1}
where load_date = '${2}'
group by load_date,substr(trim(last_upd),0,10);" >>${1}_ctl_${2}.hql

echo "\n" >>${1}_ctl_${2}.hql

echo "create temporary table audit_base_tmp_${1} as
select '${1}' as table_name,load_date, substr(trim(last_upd),0,10) as  business_date ,count(*) as base_cnt from siebel_base.${1}
where load_date = '${2}'
group by load_date,substr(trim(last_upd),0,10);" >>${1}_ctl_${2}.hql

echo "\n" >>${1}_ctl_${2}.hql


echo " INSERT INTO  TABLE siebel_base.c_record_stats
select b.table_name table_name,
b.load_date load_date,
b.business_date business_date,
b.raw_cnt total_count,
case when a.base_cnt is null then '0'  else a.base_cnt end as distinct_count,
case when a.base_cnt is null then '0'  else a.base_cnt end as unique_count,
current_timestamp as last_update
from audit_raw_tmp_${1} b 
left outer join 
audit_base_tmp_${1} a 
on b.table_name = a.table_name
and b.load_date = a.load_date
and b.business_date= a.business_date;" >>${1}_ctl_${2}.hql

hive -f ${1}_ctl_${2}.hql
rm ${1}_ctl_${2}.hql
