

SET hive.exec.dynamic.partition = true;  
SET hive.exec.dynamic.partition.mode = nonstrict;
set hive.exec.max.dynamic.partitions = 40000; 
set hive.exec.max.dynamic.partitions.pernode = 20000;
set mapreduce.map.memory.mb = 4000;
set hive.auto.conver.join = false;




insert overwrite   table cap_mi_test.service_request_event_fact partition(load_date)
select 
sr_id,
sr_number	,	
sr_process	,	
sr_area	,	
sr_sub_area	,	
sr_start_date	,	
sr_start_time	,	
sr_end_date	,	
sr_end_time	,	
sr_reason	,	
sr_due_date	,	
sr_resolution_code	,	
sr_status	,	
sr_sub_status	,	
sr_next_action_due_date	,	
sr_source	,	
sr_case_id	,	
sr_owner_employee_id	,	
sr_created_date	,	
sr_updated_date	,	
sr_version_number	,	
sr_x_uniq_ref_num	,	
	
sr_status_id	,	
sr_status_name	,	
sr_status_val	,	
sr_status_start_date	,	
sr_status_end_date	,	
sr_status_created_date	,	
sr_status_update_date	,	
sr_status_version_number	,	
sr_status_batch_number	,	
sr_sub_status_id	,	
sr_sub_status_name	,	
sr_sub_status_val	,	
sr_sub_status_start_date	,	
sr_sub_status_end_date	,	
sr_sub_status_created_date	,	
sr_sub_status_update_date	,	
sr_sub_status_version_number	,	
sr_sub_status_batch_number	,	
contact_id	,	
contact_scin	,	
contact_created_date	,	
contact_update_date	,	
contact_version_number	,	
case_id	,	
case_number	,	
case_master_case_number	,	
case_created_date	,	
case_update_date	,	
case_version_number	,	
employer_name	,	
employer_reference_number	,	
region	,	
segment	,	
sub_segment	,	
division	,	
sub_divn	,	
team	,
case when (upper(trim(sr_status)) ='CLOSED' and sr_due_date is not null and sr_end_date is not null) then 1 else 0 end  as sr_event_clearance_ind	,	
case when (sr_version_number = 0 and sr_due_date is not null and to_date(sr_created_date) = to_date(sr_start_date)) then 1 else 0 end as sr_event_intake_ind	,	
case when (upper(trim(sr_status)) !='CLOSED' and sr_end_date is  null ) then 1 else 0 end  as sr_event_work_on_hand_ind	,
business_date,
'2019-03-18' as load_date		
	

from cap_mi_test.srv_fact_0318;