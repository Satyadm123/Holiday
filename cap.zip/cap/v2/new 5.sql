DATEDIFF('day', start, stop) - 

(
(FLOOR(DATEDIFF('day', start, stop) / 7) * 2) 

+

CASE WHEN DATE_PART(dow, start) - DATE_PART(dow, stop) IN (1, 2, 3, 4, 5) AND DATE_PART(dow, stop) != 0
THEN 2 ELSE 0 END 
+
CASE WHEN DATE_PART(dow, start) != 0 AND DATE_PART(dow, stop) = 0
THEN 1 ELSE 0 END 

+
CASE WHEN DATE_PART(dow, start) = 0 AND DATE_PART(dow, stop) != 0
THEN 1 ELSE 0 END)


select from_unixtime(unix_timestamp('2019-04-14','yyyy-MM-dd'),'u')


select
datediff(to_date('2018-12-22'),to_date('2018-11-28')) ,
(floor(datediff(to_date('2018-12-22'),to_date('2018-11-28')) / 7) * 2),

case when
from_unixtime(unix_timestamp('2018-11-28','yyyy-MM-dd'),'u') - from_unixtime(unix_timestamp('2018-12-22','yyyy-MM-dd'),'u') in (1,2,3,4,5)
and from_unixtime(unix_timestamp('2018-12-22','yyyy-MM-dd'),'u') != 1  then 2 else 0 end ,

case when 
from_unixtime(unix_timestamp('2018-11-28','yyyy-MM-dd'),'u') != 7 and from_unixtime(unix_timestamp('2018-12-22','yyyy-MM-dd'),'u') = 7
then 1 else 0 end,

case when 
from_unixtime(unix_timestamp('2018-11-28','yyyy-MM-dd'),'u') = 7 and from_unixtime(unix_timestamp('2018-12-22','yyyy-MM-dd'),'u') != 7
then 1 else 0 end,

case when 
from_unixtime(unix_timestamp('2018-11-28','yyyy-MM-dd'),'u') != 6 and from_unixtime(unix_timestamp('2018-12-22','yyyy-MM-dd'),'u') = 6
then 1 else 0 end,

case when 
from_unixtime(unix_timestamp('2018-11-28','yyyy-MM-dd'),'u') = 6 and from_unixtime(unix_timestamp('2018-12-22','yyyy-MM-dd'),'u') != 6
then 1 else 0 end
;



















select * from cap_mi_test.service_request_event_fact_v2 where sr_cal_age != sr_wor_age

start_date 2018-11-28
business_date 2018-12-22
wor_age = 18
cal_age 24

select from_unixtime(unix_timestamp('2019-04-06','yyyy-MM-dd'),'u')


select
datediff(to_date('2018-12-22'),to_date('2018-11-28')) ,

(floor(datediff(to_date('2018-12-22'),to_date('2018-11-28')) / 7) * 2),

case when
from_unixtime(unix_timestamp('2018-11-28','yyyy-MM-dd'),'u') - from_unixtime(unix_timestamp('2018-12-22','yyyy-MM-dd'),'u') = 1 
and from_unixtime(unix_timestamp('2018-12-22','yyyy-MM-dd'),'u') != 0  then 2 else 0 end ,

case when
from_unixtime(unix_timestamp('2018-11-28','yyyy-MM-dd'),'u') - from_unixtime(unix_timestamp('2018-12-22','yyyy-MM-dd'),'u') = 2 
and from_unixtime(unix_timestamp('2018-12-22','yyyy-MM-dd'),'u') != 0  then 2 else 0 end ,

case when
from_unixtime(unix_timestamp('2018-11-28','yyyy-MM-dd'),'u') - from_unixtime(unix_timestamp('2018-12-22','yyyy-MM-dd'),'u') = 3 
and from_unixtime(unix_timestamp('2018-12-22','yyyy-MM-dd'),'u') != 0  then 2 else 0 end ,

case when
from_unixtime(unix_timestamp('2018-11-28','yyyy-MM-dd'),'u') - from_unixtime(unix_timestamp('2018-12-22','yyyy-MM-dd'),'u') = 4 
and from_unixtime(unix_timestamp('2018-12-22','yyyy-MM-dd'),'u') != 0  then 2 else 0 end ,

case when
from_unixtime(unix_timestamp('2018-11-28','yyyy-MM-dd'),'u') - from_unixtime(unix_timestamp('2018-12-22','yyyy-MM-dd'),'u') = 5 
and from_unixtime(unix_timestamp('2018-12-22','yyyy-MM-dd'),'u') != 0  then 2 else 0 end ,

case when 
from_unixtime(unix_timestamp('2018-11-28','yyyy-MM-dd'),'u') != 0 and from_unixtime(unix_timestamp('2018-12-22','yyyy-MM-dd'),'u') = 0
then 1 else 0 end,

case when 
from_unixtime(unix_timestamp('2018-11-28','yyyy-MM-dd'),'u') = 0 and from_unixtime(unix_timestamp('2018-12-22','yyyy-MM-dd'),'u') != 0
then 1 else 0 end






select 
datediff(to_date('2018-12-04'),to_date('2018-12-02')) 

select 
datediff(to_date('2018-12-04'),to_date('2018-12-02')) ,
- ( 2 * (( (YEAR('2018-12-04') - YEAR('2018-12-02')) * 52) + (WEEKOFYEAR('2018-12-04') - WEEKOFYEAR('2018-12-02') )) ),
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2018-12-04', 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end ,
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2018-12-02', 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 


select 
datediff(to_date('2018-12-04'),to_date('2018-12-02')) 
,( 2 * (( (YEAR('2018-12-04') - YEAR('2018-12-02')) * 52) + (WEEKOFYEAR('2018-12-04') - WEEKOFYEAR('2018-12-02') )) )
, case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2018-12-04', 'yyyy-MM-dd'), 'EEE')) = 'SAT' 
    or  upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2018-12-04', 'yyyy-MM-dd'), 'EEE')) = 'SUN' then 1 else 0 end  
, case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2018-12-02', 'yyyy-MM-dd'), 'EEE')) = 'SAT' 
    or  upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2018-12-02', 'yyyy-MM-dd'), 'EEE')) = 'SUN' then 1 else 0 end 
, WEEKOFYEAR('2018-12-04')
, WEEKOFYEAR('2018-12-02')


select 
datediff(to_date('2018-12-04'),to_date('2018-12-02')) ,
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2018-12-04', 'yyyy-MM-dd'), 'EEE')) = 'SAT' 
    or  upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2018-12-04', 'yyyy-MM-dd'), 'EEE')) = 'SUN' then 1 else 0 end ,
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2018-12-02', 'yyyy-MM-dd'), 'EEE')) = 'SAT' 
    or  upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2018-12-02', 'yyyy-MM-dd'), 'EEE')) = 'SUN' then 1 else 0 end 


select 
upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2018-12-09', 'YYYY-MM-DD'), 'EEE'))  , 
upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2018-12-02', 'YYYY-MM-DD'), 'EEE')) 


select 
from_unixtime(unix_timestamp('2018-12-02','yyyy-MM-dd'),'EEE')





select YEAR('2018-12-04'),WEEKOFYEAR('2018-12-04'),WEEKOFYEAR('2018-12-02') 

select

  datediff(to_date('2018-12-22'),to_date('2018-11-28')) - 1
- ( 2 * (( (YEAR('2018-12-22') - YEAR('2018-11-28')) * 52) + (WEEKOFYEAR('2018-12-22') - WEEKOFYEAR('2018-11-28') )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2018-12-22', 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP('2018-11-28', 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
- case when cast('2018-11-28' as date) <= cast('2018-08-06' as date) and cast('2018-12-22' as date) >= cast('2018-08-06' as date) then 1 else 0 end
- case when cast('2018-11-28' as date) <= cast('2018-08-27' as date) and cast('2018-12-22' as date) >= cast('2018-08-27' as date) then 1 else 0 end
- case when cast('2018-11-28' as date) <= cast('2018-12-24' as date) and cast('2018-12-22' as date) >= cast('2018-12-24' as date) then 1 else 0 end
- case when cast('2018-11-28' as date) <= cast('2018-12-25' as date) and cast('2018-12-22' as date) >= cast('2018-12-25' as date) then 1 else 0 end
- case when cast('2018-11-28' as date) <= cast('2018-12-26' as date) and cast('2018-12-22' as date) >= cast('2018-12-26' as date) then 1 else 0 end
- case when cast('2018-11-28' as date) <= cast('2019-01-01' as date) and cast('2018-12-22' as date) >= cast('2019-01-01' as date) then 1 else 0 end
- case when cast('2018-11-28' as date) <= cast('2019-02-01' as date) and cast('2018-12-22' as date) >= cast('2019-02-01' as date) then 1 else 0 end
- case when cast('2018-11-28' as date) <= cast('2019-03-18' as date) and cast('2018-12-22' as date) >= cast('2019-03-18' as date) then 1 else 0 end
- case when cast('2018-11-28' as date) <= cast('2019-04-19' as date) and cast('2018-12-22' as date) >= cast('2019-04-19' as date) then 1 else 0 end 
