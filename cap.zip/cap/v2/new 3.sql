Select
count(*)
from 
cap_mi_test.tmp_srv_fact set_fact
left join sr_sla s on 
set_fact.sr_process = s.process and set_fact.sr_area = s.area and set_fact.sr_sub_area = s.subarea
left join age_band age on upper(trim(cast(cast(nvl(s.sla, '-1')  as int) as string))) = upper(trim(cast(age.total_sla as string))) 
left join age_band age_w on upper(trim(cast(cast(nvl(s.sla, '-1')  as int) as string))) = upper(trim(cast(age_w.total_sla as string))) 
where 
age.start_day <=
case when set_fact.sr_event_clearance_ind = '1' then datediff(to_date(set_fact.sr_end_date),to_date(set_fact.sr_start_date)) 
else case when set_fact.sr_event_work_on_hand_ind = '1' then datediff(to_date(set_fact.business_date),to_date(set_fact.sr_start_date)) 
end end  
and age.end_day > case when set_fact.sr_event_clearance_ind = '1' then datediff(to_date(set_fact.sr_end_date),to_date(set_fact.sr_start_date)) 
else case when set_fact.sr_event_work_on_hand_ind = '1' then datediff(to_date(set_fact.business_date),to_date(set_fact.sr_start_date)) 
end end
and 
age_w.start_day <=


case when set_fact.sr_event_clearance_ind = '1' then 

case when 
(datediff(to_date(set_fact.sr_end_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.sr_end_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.sr_end_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_end_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end ) < 0 then 0 
else 
datediff(to_date(set_fact.sr_end_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.sr_end_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.sr_end_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_end_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
end 

--- end date ingest
else case when set_fact.sr_event_work_on_hand_ind = '1' then 

case when
(datediff(to_date(set_fact.business_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.business_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.business_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.business_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end  ) < 0 then 0
else
datediff(to_date(set_fact.business_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.business_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.business_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.business_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
end
-- businee date ingest
end end  
and age_w.end_day > 

case when set_fact.sr_event_clearance_ind = '1' then 
case when
(datediff(to_date(set_fact.sr_end_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.sr_end_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.sr_end_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_end_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end ) < 0 then 0
else
datediff(to_date(set_fact.sr_end_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.sr_end_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.sr_end_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_end_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
end

--- end date ingest
else case when set_fact.sr_event_work_on_hand_ind = '1' then 

case when
(datediff(to_date(set_fact.business_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.business_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.business_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.business_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end ) < 0 then 0
else
datediff(to_date(set_fact.business_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.business_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.business_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.business_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
end

-- businee date ingest

end end