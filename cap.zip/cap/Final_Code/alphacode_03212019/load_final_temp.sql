set mapreduce.map.memory.mb = 4000;

create  table cap_mi_test.srv_fact_0317_1 as 
select
sr_id	,	
sr_number	,	
sr_process	,	
sr_area	,	
sr_sub_area	,	
sr_start_date	,	
sr_start_time	,	
sr_end_date	,	
sr_end_time	,	
sr_reason	,	
sr_due_date	,	
sr_resolution_code	,	
sr_status	,	
sr_sub_status	,	
sr_next_action_due_date	,	
sr_source	,	
sr_case_id	,	
sr_owner_employee_id	,	
sr_created_date	,	
sr_updated_date	,	
sr_version_number	,	
sr_x_uniq_ref_num ,
v_service_request_dim.load_date, 
v_service_request_dim.business_date,
sr_status_id	,	
sr_status_name	,	
sr_status_val	,	
sr_status_start_date	,	
sr_status_end_date	,	
sr_status_created_date	,	
sr_status_update_date	,	
sr_status_version_number	,	
sr_status_batch_number	,
sr_sub_status_id	,	
sr_sub_status_name	,	
sr_sub_status_val	,	
sr_sub_status_start_date	,	
sr_sub_status_end_date	,	
sr_sub_status_created_date	,	
sr_sub_status_update_date	,	
sr_sub_status_version_number	,	
sr_sub_status_batch_number	
--contact_id	,	
--contact_scin	,	
--contact_created_date	,	
--contact_update_date	,	
--contact_version_number	,
--case_id	,	
--case_number	,	
--case_master_case_number	,	
--case_created_date	,	
--case_update_date	,	
--case_version_number	,
--org.name  as employer_name ,
--org.x_ern_arn as employer_reference_number
--org_pos.region ,
--org_pos.segment ,
--org_pos.sub_segment ,
--org_pos.division ,
--org_pos.sub_divn ,
--team 
from cap_mi_test.v_service_request_dim 
inner join cap_mi_test.v_service_request_status_dim
on v_service_request_dim.sr_id =v_service_request_status_dim.sr_status_id
inner join cap_mi_test.v_service_request_sub_status_dim
on v_service_request_dim.sr_id =v_service_request_sub_status_dim.sr_sub_status_id;




---------------------------------------------------




create  table cap_mi_test.srv_fact_0318 as 
select
sr_id	,	
sr_number	,	
sr_process	,	
sr_area	,	
sr_sub_area	,	
sr_start_date	,	
sr_start_time	,	
sr_end_date	,	
sr_end_time	,	
sr_reason	,	
sr_due_date	,	
sr_resolution_code	,	
sr_status	,	
sr_sub_status	,	
sr_next_action_due_date	,	
sr_source	,	
sr_case_id	,	
sr_owner_employee_id	,	
sr_created_date	,	
sr_updated_date	,	
sr_version_number	,	
cast(sr_x_uniq_ref_num as int) sr_x_uniq_ref_num ,
sr.load_date, 
sr.business_date,
sr_status_id	,	
sr_status_name	,	
sr_status_val	,	
sr_status_start_date	,	
sr_status_end_date	,	
sr_status_created_date	,	
sr_status_update_date	,	
sr_status_version_number	,	
sr_status_batch_number	,
sr_sub_status_id	,	
sr_sub_status_name	,	
sr_sub_status_val	,	
sr_sub_status_start_date	,	
sr_sub_status_end_date	,	
sr_sub_status_created_date	,	
sr_sub_status_update_date	,	
sr_sub_status_version_number	,	
sr_sub_status_batch_number	,
contact_id	,	
contact_scin	,	
contact_created_date	,	
contact_update_date	,	
contact_version_number	,
case_id	,	
case_number	,	
case_master_case_number	,	
case_created_date	,	
case_update_date	,	
case_version_number	,
org.name employer_name ,
org.x_ern_arn employer_reference_number,
org_pos.region ,
org_pos.segment ,
org_pos.sub_segment ,
org_pos.division ,
org_pos.sub_divn ,
org_pos.team 
from cap_mi_test.srv_fact_0317_1 sr

left outer join cap_mi_2012.v_contact_dim
on sr.sr_owner_employee_id = v_contact_dim.contact_id
left outer join siebel_base.s_postn pos 
on pos.row_id = v_contact_dim.contact_position and trim(pos.current_flg)='Y'
left outer join cap_mi_2012.v_case_dim
on sr.sr_case_id=v_case_dim.case_id
left outer join siebel_base.s_org_ext org 
on pos.ou_id =org.row_id and trim(org.current_flg)='Y'

left outer join siebel_base.s_org_pos_h org_pos
on cast(sr.sr_x_uniq_ref_num as int) = org_pos.position_wid;