create table ${hivevar:dbName}.sr_sla as
select 
    subarea.row_id,
    procarea.proc as process,
    procarea.proclic as process_i,
    procarea.area,
    procarea.arealic as area_i,
    subarea.val as subarea,
    subarea.val as subarea_i,
    subarea.target_high as sla
from 
(
		select 
		t2.val proc,t2.name proclic,
		t1.val area, t1.name arealic
		from 
		${hivevar:dbName_base}.s_lst_of_val t1
		inner join ${hivevar:dbName_base}.s_lst_of_val t2 on t1.par_row_id = t2.row_id
		where 
		    ((t1.active_flg ='Y' or t1.active_flg is null ) and 
			(t1.type ='SR_AREA' and t1.bu_id is null  
			and t2.val in (select val from ${hivevar:dbName_base}.s_lst_of_val where par_row_id is null and type ='SR_AREA'  and active_flg='Y'  
			and order_by >=1000 and order_by <=1500)
			))
		order by t2.val
) procarea ,
${hivevar:dbName_base}.s_lst_of_val subarea,
${hivevar:dbName_base}.s_lst_of_val parsubarea
where 
subarea.par_row_id in
(
	select t1.par_row_id 
	from ${hivevar:dbName_base}.s_lst_of_val t1
	inner join ${hivevar:dbName_base}.s_lst_of_val t2 on t1.par_row_id = t2.row_id
	where 
	(
	   (t1.active_flg ='Y' or t1.active_flg is null) and (t2.val is not null) and 
	   ( 
		 t2.type ='SR_AREA' and t1.type ='SR_AREA'  and t1.bu_id  is null and 
		 t2.name in 
		 (
			select concat(t2.name, ' ', t1.name) arealic 
			from ${hivevar:dbName_base}.s_lst_of_val t1 
			inner join ${hivevar:dbName_base}.s_lst_of_val t2 on t1.par_row_id = t2.row_id
			where 
			(
				(t1.active_flg ='Y' or t1.active_flg is null ) and 
				(
				  t1.type = 'SR_AREA' and t1.bu_id is null and 
				  t2.val in
				  (
					select val 
					from ${hivevar:dbName_base}.s_lst_of_val where par_row_id is null and type ='SR_AREA'  and active_flg='Y'  
					and order_by >=1000 and order_by <=1500
				  )
				)
			)
		 )
	  )
	)
)
and subarea.active_flg = 'Y' and subarea.type ='SR_AREA'
and subarea.par_row_id = parsubarea.row_id 
and parsubarea.name = concat(procarea.proclic, ' ', procarea.arealic)