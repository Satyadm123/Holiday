while read a b c d e f
do
   echo /home/satyas.dasmohp@SDP.LOCAL/scripts/cap/cap_sqoop_siebel.sh $a $b $c $d $e $f  `date +%Y-%m-%d` > /home/satyas.dasmohp@SDP.LOCAL/scripts/tmp_run/sqoop_run_$c.sh
done < /home/satyas.dasmohp@SDP.LOCAL/scripts/cap/param_file.txt

cd /home/satyas.dasmohp@SDP.LOCAL/scripts/tmp_run
chmod 755 *.sh
for script in /home/satyas.dasmohp@SDP.LOCAL/scripts/tmp_run/*.sh; do "$script" & done
wait
