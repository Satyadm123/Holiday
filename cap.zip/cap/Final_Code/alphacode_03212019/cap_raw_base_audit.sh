echo "drop table if exists audit_raw_tmp_${1}_main;">${1}_ctl_${2}.hql
echo "drop table if exists audit_raw_tmp_${1}_all;">>${1}_ctl_${2}.hql
echo "drop table if exists audit_raw_tmp_${1}_unique;">>${1}_ctl_${2}.hql
echo "drop table if exists audit_base_tmp_${1};" >>${1}_ctl_${2}.hql


echo "\n" >>${1}_ctl_${2}.hql



echo "create temporary table audit_raw_tmp_${1}_main as
select
row_number () over (partition by row_id,to_date(last_upd) order by last_upd desc) as row_id_no,
count(*) over (partition by row_id,to_date(last_upd) ) as row_id_count,
to_date(last_upd) as business_date,
load_date

from ${3}.${1}
where load_date = '${2}';" >>${1}_ctl_${2}.hql

echo "\n" >>${1}_ctl_${2}.hql

echo "create temporary table audit_raw_tmp_${1}_all as
select '${1}' as table_name,
load_date,
business_date,count(*) as raw_cnt from 

audit_raw_tmp_${1}_main A

group by load_date,business_date;" >>${1}_ctl_${2}.hql

echo "\n" >>${1}_ctl_${2}.hql
echo "create temporary table audit_raw_tmp_${1}_unique as
select '${1}' as table_name,
load_date,
business_date,count(*) as unique_cnt from 

audit_raw_tmp_${1}_main A
where  A.row_id_no = 1 and  A.row_id_count=1
group by load_date,business_date;" >>${1}_ctl_${2}.hql



echo "\n" >>${1}_ctl_${2}.hql

echo "create temporary table audit_base_tmp_${1} as
select '${1}' as table_name,load_date, business_date ,count(*) as base_cnt from ${4}.${1}
where load_date = '${2}'
group by load_date,business_date;" >>${1}_ctl_${2}.hql

echo "\n" >>${1}_ctl_${2}.hql


echo " INSERT INTO  TABLE ${4}.c_record_stats
select b.table_name table_name,
b.load_date load_date,
b.business_date business_date,
b.raw_cnt total_count,
case when a.base_cnt is null then '0'  else a.base_cnt end as distinct_count,
c.unique_cnt as unique_cnt,
current_timestamp as last_update
from audit_raw_tmp_${1}_all b
left outer join
audit_base_tmp_${1} a
on b.table_name = a.table_name
and b.load_date = a.load_date
and b.business_date= a.business_date
left outer join audit_raw_tmp_${1}_unique c 
on b.table_name = c.table_name
and b.load_date = c.load_date
and b.business_date= c.business_date;" >>${1}_ctl_${2}.hql


hive -f ${1}_ctl_${2}.hql
rm ${1}_ctl_${2}.hql

