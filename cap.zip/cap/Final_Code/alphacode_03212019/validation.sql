set mapreduce.map.memory.mb = 3000;
select count(*) from cap_mi_test.v_service_request_dim

 inner join cap_mi_2012.v_contact_dim
on v_service_request_dim.sr_owner_employee_id = v_contact_dim.contact_id 
where v_contact_dim.contact_scin is not null;

set mapreduce.map.memory.mb = 3000;
select count(*) from cap_mi_test.v_service_request_dim

 inner join 
 (
 select Con.row_id as row_id,bu.x_scin_num as contact_scin
 from
 (select B.row_id,bu_id from 
(select row_id,bu_id,row_number () over (partition by row_id order by business_date desc) as rownum
from siebel_base.s_contact where current_flg='Y') B
where B.rownum = 1)Con

left outer join
(
	select 
	`s_contact_bu`.`contact_id`,`s_contact_bu`.`bu_id`,`s_contact_bu`.`x_scin_num`
	from `siebel_base`.`s_contact_bu`
	where `s_contact_bu`.`x_scin_num` is not null 
	)`bu` on 
	`con`.`row_id`=`bu`.`contact_id` and `con`.`bu_id`=`bu`.`bu_id`) D
on v_service_request_dim.sr_owner_employee_id = D.row_id 
where D.contact_scin is not null;

--7236662



show create table  cap_mi_2012.v_contact_dim;

(select B.row_id from 
(select row_id,row_number () over (partition by row_id order by business_date desc) as rownum
from siebel_base.s_contact where current_flg='Y') B
where B.rownum = 1)C