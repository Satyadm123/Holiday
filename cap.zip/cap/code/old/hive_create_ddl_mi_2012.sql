CREATE DATABASE IF NOT EXISTS ${hiveconf:dbName} COMMENT 'Siebel MI 2012 database' LOCATION '${hiveconf:hdfsDIR}';


CREATE EXTERNAL TABLE IF NOT EXISTS cap_mi_2012.service_request_event_fact
(
service_request_id string,
service_request_number string,
service_request_process string,
service_request_area string,
service_request_sub_area string,
service_request_start_date string,
service_request_start_time string,
service_request_end_date string,
service_request_end_time string,
service_request_reason string,
service_request_due_date string,
service_request_resolution_code string,
service_request_status string,
service_request_sub_status string,
service_next_action_due_date string,
service_request_source string,
service_request_case_id string,
service_request_owner_employee_id string,
service_request_created_date string,
service_request_updated_date string,
service_request_version_number string,
service_request_event_intake_ind string,
service_request_event_clearance_ind string,
contact_id string,
contact_scin string,
contact_created_date string,
contact_update_date string,
contact_version_number string,
case_id string,
case_number string,
case_master_case_number string,
case_created_date string, 
case_update_date string,
case_version_number string,
)
PARTITIONED BY (load_date STRING, business_date STRING)
STORED AS AVRO
LOCATION '/user/hive/warehouse/cap/mi_2012.db/service_request_event_fact';



drop view cap_mi_2012.v_service_request_dim;

CREATE VIEW `v_service_request_dim` AS SELECT 
`sr`.`cx_row_id` `service_request_id`,
`sr`.`sr_num` `service_request_number`,
`sr`.`ins_product` `service_request_process`,
`sr`.`sr_area` `service_request_area`,
`sr`.`sr_sub_area` `service_request_sub_area`,
`sr`.`created` `service_request_start_date`,
`sr`.`created` `service_request_start_time`,
`sr`.`act_close_dt` `service_request_end_date`,
`sr`.`act_close_dt` `service_request_end_time`,
`sr`.`reason_cd` `service_request_reason`,
`sr`.`cem_due_dt` `service_request_due_date`,
`sr`.`resolution_cd` `service_request_resolution_code`,
`sr`.`sr_stat_id` `service_request_status`,
`sr`.`sr_sub_stat_id` `service_request_sub_status`,
`sr`.`x_next_act_date` `service_next_action_due_date`,
`sr`.`sr_subtype_cd` `service_request_source`,
`sr`.`case_id` `service_request_case_id`,
`sr`.`owner_emp_id` `service_request_owner_employee_id`,
`sr`.`act_open_dt` `service_request_created_date`,
`sr`.`last_upd` `service_request_updated_date`,
`sr`.`modification_num` `service_request_version_number`,
`sr`.`load_date` `load_date`,
`sr`.`business_date` `business_date`
FROM `siebel_base`.`cx_intraday_s_srv_req` `sr` 
WHERE upper(trim(`sr`.`template_flg`)) != 'Y';


drop view cap_mi_2012.v_service_request_status_dim;

CREATE VIEW `v_service_request_status_dim` AS SELECT s.cx_row_id service_request_status_id, 
CASE WHEN l.name IS NULL THEN s.sr_stat_id ELSE l.name END service_request_status_name, 
CASE WHEN l.val IS NULL THEN s.sr_stat_id ELSE l.val END service_request_status_val,
 '' service_request_status_start_date, '' service_request_status_end_date, 
 '' service_request_status_created_date, '' service_request_status_update_date, '' service_request_status_version_number, '' service_request_status_batch_number 
 FROM siebel_base.cx_intraday_s_srv_req s LEFT OUTER JOIN siebel_base.s_lst_of_val l ON (s.sr_stat_id = l.val) WHERE upper(trim(l.type)) = 'SR_STATUS';


drop view v_service_request_sub_status_dim;

CREATE VIEW `v_service_request_sub_status_dim` AS SELECT s.cx_row_id service_request_sub_status_id, CASE WHEN l.name IS NULL THEN s.sr_sub_stat_id ELSE l.name END 
service_request_sub_status_name, CASE WHEN l.val IS NULL THEN s.sr_sub_stat_id ELSE l.val END service_request_sub_status_val, '' service_request_sub_status_start_date, 
'' service_request_sub_status_end_date, '' service_request_sub_status_created_date, '' service_request_sub_status_update_date, '' service_request_sub_status_version_number, 
'' service_request_sub_status_batch_number 
FROM siebel_base.cx_intraday_s_srv_req s LEFT OUTER JOIN 
(SELECT DISTINCT s.name, s.val, s.type FROM siebel_base.s_lst_of_val s WHERE upper(trim(s.type)) = 'SR_SUB_STATUS') l ON (s.sr_sub_stat_id = l.val);



CREATE VIEW v_contact_dim AS select
con.row_id as contact_id,
bu.x_scin_num as contact_scin,
con.created as contact_created_date, 
con.last_upd as contact_update_date,
con.modification_num as contact_version_number
from
(select `a`.`row_id_no`, `a`.`row_wid`, `a`.`row_id`, `a`.`created`, `a`.`created_by`, `a`.`last_upd`, `a`.`last_upd_by`, `a`.`dcking_num`, `a`.`modification_num`, `a`.`conflict_id`, `a`.`par_row_id`, `a`.`active_flg`, `a`.`bu_id`, `a`.`court_pay_flg`, `a`.`disa_cleanse_flg`, `a`.`disp_img_auth_flg`, `a`.`email_sr_upd_flg`, `a`.`emp_flg`, `a`.`fst_name`, `a`.`invstgtr_flg`, `a`.`last_name`, `a`.`person_uid`, `a`.`po_pay_flg`, `a`.`priv_flg`, `a`.`prospect_flg`, `a`.`ptshp_contact_flg`, `a`.`ptshp_key_con_flg`, `a`.`send_survey_flg`, `a`.`speaker_flg`, `a`.`suppress_email_flg`, `a`.`suppress_fax_flg`, `a`.`suspect_flg`, `a`.`susp_wtch_flg`, `a`.`agent_flg`, `a`.`enterprise_flag`, `a`.`member_flg`, `a`.`ok_to_sample_flg`, `a`.`provider_flg`, `a`.`pr_rep_dnrm_flg`, `a`.`pr_rep_manl_flg`, `a`.`pr_rep_sys_flg`, `a`.`send_fin_flg`, `a`.`send_news_flg`, `a`.`send_promotes_flg`, `a`.`suppress_call_flg`, `a`.`suppress_mail_flg`, `a`.`age`, `a`.`annl_incm_amt`, `a`.`annl_incm_exch_dt`, `a`.`asgn_dt`, `a`.`asgn_excld_flg2`, `a`.`asgn_required_flg2`, `a`.`asgn_usr_excld_flg`, `a`.`birth_dt`, `a`.`call_flg`, `a`.`consumer_flg`, `a`.`con_created_dt`, `a`.`credit_score`, `a`.`cust_end_dt`, `a`.`cust_since_dt`, `a`.`db_last_upd`, `a`.`death_dt`, `a`.`dedup_dataclnsd_dt`, `a`.`dedup_key_upd_dt`, `a`.`dedup_last_mtch_dt`, `a`.`hard_to_reach`, `a`.`inves_start_dt`, `a`.`inv_org_st_dt`, `a`.`last_credit_dt`, `a`.`latitude`, `a`.`longitude`, `a`.`lst_emladr_upd_ts`, `a`.`mgmnt_flg`, `a`.`num_hard_bnce`, `a`.`num_soft_bnce`, `a`.`seminar_invit_flg`, `a`.`active_cti_cfg_id`, `a`.`active_teleset_id`, `a`.`aia_integ_id`, `a`.`alias_name`, `a`.`alt_email_addr`, `a`.`alt_email_loc_cd`, `a`.`alt_ph_num`, `a`.`annl_incm_curcy_cd`, `a`.`approval_status_cd`, `a`.`area_id`, `a`.`asst_ph_num`, `a`.`call_frequency`, `a`.`cell_ph_num`, `a`.`citizenship_cd`, `a`.`comments`, `a`.`complexion_cd`, `a`.`con_asst_name`, `a`.`con_asst_per_id`, `a`.`con_cd`, `a`.`con_exper_cd`, `a`.`con_image_id`, `a`.`con_influnc_id`, `a`.`con_manager_name`, `a`.`con_manager_per_id`, `a`.`corp_ptrnl_lstname`, `a`.`country_template`, `a`.`creator_login`, `a`.`credit_agency`, `a`.`csn`, `a`.`curr_pri_lst_id`, `a`.`cust_stat_cd`, `a`.`cust_value_cd`, `a`.`db_last_upd_src`, `a`.`decision_type_cd`, `a`.`dedup_token`, `a`.`degree`, `a`.`dflt_order_proc_cd`, `a`.`email_addr`, `a`.`email_loc_cd`, `a`.`email_status_cd`, `a`.`emplmnt_stat_cd`, `a`.`emp_id`, `a`.`emp_num`, `a`.`emp_work_loc_name`, `a`.`ethnicity_cd`, `a`.`eye_color`, `a`.`fax_ph_num`, `a`.`furi_ptrnl_lstname`, `a`.`hair_color`, `a`.`height`, `a`.`height_uom_cd`, `a`.`home_ph_num`, `a`.`indust_id`, `a`.`integration_id`, `a`.`job_title`, `a`.`left_eye_clr_cd`, `a`.`login`, `a`.`maiden_name`, `a`.`marital_stat_cd`, `a`.`med_spec_id`, `a`.`mid_name`, `a`.`mother_maiden_name`, `a`.`mstr_case_id`, `a`.`nationality`, `a`.`new_user_resp_name`, `a`.`nick_name`, `a`.`occupation`, `a`.`ou_id`, `a`.`ou_mail_stop`, `a`.`owner_login`, `a`.`owner_per_id`, `a`.`pager_company_id`, `a`.`pager_num`, `a`.`pager_ph_num`, `a`.`pager_pin`, `a`.`pager_type_cd`, `a`.`password`, `a`.`paternal_last_name`, `a`.`per_title`, `a`.`per_title_suffix`, `a`.`place_of_birth`, `a`.`postn_cd`, `a`.`practice_type`, `a`.`pref_comm_media_cd`, `a`.`pref_comm_meth_cd`, `a`.`pref_lang_id`, `a`.`pref_locale_id`, `a`.`pref_sale_dlr_id`, `a`.`presence_uri`, `a`.`privacy_cd`, `a`.`pr_act_id`, `a`.`pr_affl_id`, `a`.`pr_alt_ph_num_id`, `a`.`pr_asset_id`, `a`.`pr_bl_per_addr_id`, `a`.`pr_client_ou_id`, `a`.`pr_comm_lang_id`, `a`.`pr_con_addr_id`, `a`.`pr_cst_accnt_id`, `a`.`pr_cti_cfg_id`, `a`.`pr_dept_ou_id`, `a`.`pr_drvr_license_id`, `a`.`pr_email_addr_id`, `a`.`pr_facility_id`, `a`.`pr_grp_ou_id`, `a`.`pr_held_postn_id`, `a`.`pr_image_id`, `a`.`pr_indust_id`, `a`.`pr_mkt_seg_id`, `a`.`pr_note_id`, `a`.`pr_opty_id`, `a`.`pr_ou_addr_id`, `a`.`pr_per_addr_id`, `a`.`pr_per_pay_prfl_id`, `a`.`pr_phone_id`, `a`.`pr_postn_id`, `a`.`pr_prod_id`, `a`.`pr_prod_ln_id`, `a`.`pr_region_id`, `a`.`pr_resp_id`, `a`.`pr_security_id`, `a`.`pr_sh_per_addr_id`, `a`.`pr_specialty_id`, `a`.`pr_state_lic_id`, `a`.`pr_sync_user_id`, `a`.`pr_terr_id`, `a`.`pr_userrole_id`, `a`.`race`, `a`.`rating`, `a`.`region_id`, `a`.`regl_stat_cd`, `a`.`reliability_cd`, `a`.`resident_stat_cd`, `a`.`right_eye_clr_cd`, `a`.`route`, `a`.`sec_answr`, `a`.`sec_quest_cd`, `a`.`sex_mf`, `a`.`soc_security_num`, `a`.`spouse_last_name`, `a`.`src_id`, `a`.`status_cd`, `a`.`stat_reason_cd`, `a`.`stock_portfolio`, `a`.`sub_spec_id`, `a`.`svc_branch_id`, `a`.`timezone_id`, `a`.`tmzone_cd`, `a`.`weathr_loc_pref`, `a`.`web_region_id`, `a`.`weight`, `a`.`weight_uom_cd`, `a`.`work_ph_num`, `a`.`x_suppress_notifications`, `a`.`x_unearned_income1`, `a`.`x_unearned_income2`, `a`.`x_unearned_income3`, `a`.`x_unearned_income_date`, `a`.`x_unearned_income_year`, `a`.`x_current_income`, `a`.`x_personal_interest`, `a`.`x_sensitive_contact`, `a`.`x_notional_ben_inc_asses`, `a`.`x_dob_cisverified`, `a`.`x_allow_status`, `a`.`x_hmrc_deo_sourced_date`, `a`.`effective_from_dt`, `a`.`effective_to_dt`, `a`.`current_flg`, `a`.`load_dt`, `a`.`etl_proc_wid`, `a`.`change_flg`, `a`.`x_tam_status`, `a`.`x_bankrupt_date`, `a`.`x_bankrupt_status`, `a`.`x_point_of_contact`, `a`.`x_primary_contact_flg`, `a`.`x_seq_num`, `a`.`x_spec_req_id`, `a`.`x_work_ph_ext`, `a`.`load_date`, `a`.`business_date`, `a`.`rownum` from 
(select `s_contact_0313`.`row_id_no`, `s_contact_0313`.`row_wid`, `s_contact_0313`.`row_id`, `s_contact_0313`.`created`, `s_contact_0313`.`created_by`, `s_contact_0313`.`last_upd`, `s_contact_0313`.`last_upd_by`, `s_contact_0313`.`dcking_num`, `s_contact_0313`.`modification_num`, `s_contact_0313`.`conflict_id`, `s_contact_0313`.`par_row_id`, `s_contact_0313`.`active_flg`, `s_contact_0313`.`bu_id`, `s_contact_0313`.`court_pay_flg`, `s_contact_0313`.`disa_cleanse_flg`, `s_contact_0313`.`disp_img_auth_flg`, `s_contact_0313`.`email_sr_upd_flg`, `s_contact_0313`.`emp_flg`, `s_contact_0313`.`fst_name`, `s_contact_0313`.`invstgtr_flg`, `s_contact_0313`.`last_name`, `s_contact_0313`.`person_uid`, `s_contact_0313`.`po_pay_flg`, `s_contact_0313`.`priv_flg`, `s_contact_0313`.`prospect_flg`, `s_contact_0313`.`ptshp_contact_flg`, `s_contact_0313`.`ptshp_key_con_flg`, `s_contact_0313`.`send_survey_flg`, `s_contact_0313`.`speaker_flg`, `s_contact_0313`.`suppress_email_flg`, `s_contact_0313`.`suppress_fax_flg`, `s_contact_0313`.`suspect_flg`, `s_contact_0313`.`susp_wtch_flg`, `s_contact_0313`.`agent_flg`, `s_contact_0313`.`enterprise_flag`, `s_contact_0313`.`member_flg`, `s_contact_0313`.`ok_to_sample_flg`, `s_contact_0313`.`provider_flg`, `s_contact_0313`.`pr_rep_dnrm_flg`, `s_contact_0313`.`pr_rep_manl_flg`, `s_contact_0313`.`pr_rep_sys_flg`, `s_contact_0313`.`send_fin_flg`, `s_contact_0313`.`send_news_flg`, `s_contact_0313`.`send_promotes_flg`, `s_contact_0313`.`suppress_call_flg`, `s_contact_0313`.`suppress_mail_flg`, `s_contact_0313`.`age`, `s_contact_0313`.`annl_incm_amt`, `s_contact_0313`.`annl_incm_exch_dt`, `s_contact_0313`.`asgn_dt`, `s_contact_0313`.`asgn_excld_flg2`, `s_contact_0313`.`asgn_required_flg2`, `s_contact_0313`.`asgn_usr_excld_flg`, `s_contact_0313`.`birth_dt`, `s_contact_0313`.`call_flg`, `s_contact_0313`.`consumer_flg`, `s_contact_0313`.`con_created_dt`, `s_contact_0313`.`credit_score`, `s_contact_0313`.`cust_end_dt`, `s_contact_0313`.`cust_since_dt`, `s_contact_0313`.`db_last_upd`, `s_contact_0313`.`death_dt`, `s_contact_0313`.`dedup_dataclnsd_dt`, `s_contact_0313`.`dedup_key_upd_dt`, `s_contact_0313`.`dedup_last_mtch_dt`, `s_contact_0313`.`hard_to_reach`, `s_contact_0313`.`inves_start_dt`, `s_contact_0313`.`inv_org_st_dt`, `s_contact_0313`.`last_credit_dt`, `s_contact_0313`.`latitude`, `s_contact_0313`.`longitude`, `s_contact_0313`.`lst_emladr_upd_ts`, `s_contact_0313`.`mgmnt_flg`, `s_contact_0313`.`num_hard_bnce`, `s_contact_0313`.`num_soft_bnce`, `s_contact_0313`.`seminar_invit_flg`, `s_contact_0313`.`active_cti_cfg_id`, `s_contact_0313`.`active_teleset_id`, `s_contact_0313`.`aia_integ_id`, `s_contact_0313`.`alias_name`, `s_contact_0313`.`alt_email_addr`, `s_contact_0313`.`alt_email_loc_cd`, `s_contact_0313`.`alt_ph_num`, `s_contact_0313`.`annl_incm_curcy_cd`, `s_contact_0313`.`approval_status_cd`, `s_contact_0313`.`area_id`, `s_contact_0313`.`asst_ph_num`, `s_contact_0313`.`call_frequency`, `s_contact_0313`.`cell_ph_num`, `s_contact_0313`.`citizenship_cd`, `s_contact_0313`.`comments`, `s_contact_0313`.`complexion_cd`, `s_contact_0313`.`con_asst_name`, `s_contact_0313`.`con_asst_per_id`, `s_contact_0313`.`con_cd`, `s_contact_0313`.`con_exper_cd`, `s_contact_0313`.`con_image_id`, `s_contact_0313`.`con_influnc_id`, `s_contact_0313`.`con_manager_name`, `s_contact_0313`.`con_manager_per_id`, `s_contact_0313`.`corp_ptrnl_lstname`, `s_contact_0313`.`country_template`, `s_contact_0313`.`creator_login`, `s_contact_0313`.`credit_agency`, `s_contact_0313`.`csn`, `s_contact_0313`.`curr_pri_lst_id`, `s_contact_0313`.`cust_stat_cd`, `s_contact_0313`.`cust_value_cd`, `s_contact_0313`.`db_last_upd_src`, `s_contact_0313`.`decision_type_cd`, `s_contact_0313`.`dedup_token`, `s_contact_0313`.`degree`, `s_contact_0313`.`dflt_order_proc_cd`, `s_contact_0313`.`email_addr`, `s_contact_0313`.`email_loc_cd`, `s_contact_0313`.`email_status_cd`, `s_contact_0313`.`emplmnt_stat_cd`, `s_contact_0313`.`emp_id`, `s_contact_0313`.`emp_num`, `s_contact_0313`.`emp_work_loc_name`, `s_contact_0313`.`ethnicity_cd`, `s_contact_0313`.`eye_color`, `s_contact_0313`.`fax_ph_num`, `s_contact_0313`.`furi_ptrnl_lstname`, `s_contact_0313`.`hair_color`, `s_contact_0313`.`height`, `s_contact_0313`.`height_uom_cd`, `s_contact_0313`.`home_ph_num`, `s_contact_0313`.`indust_id`, `s_contact_0313`.`integration_id`, `s_contact_0313`.`job_title`, `s_contact_0313`.`left_eye_clr_cd`, `s_contact_0313`.`login`, `s_contact_0313`.`maiden_name`, `s_contact_0313`.`marital_stat_cd`, `s_contact_0313`.`med_spec_id`, `s_contact_0313`.`mid_name`, `s_contact_0313`.`mother_maiden_name`, `s_contact_0313`.`mstr_case_id`, `s_contact_0313`.`nationality`, `s_contact_0313`.`new_user_resp_name`, `s_contact_0313`.`nick_name`, `s_contact_0313`.`occupation`, `s_contact_0313`.`ou_id`, `s_contact_0313`.`ou_mail_stop`, `s_contact_0313`.`owner_login`, `s_contact_0313`.`owner_per_id`, `s_contact_0313`.`pager_company_id`, `s_contact_0313`.`pager_num`, `s_contact_0313`.`pager_ph_num`, `s_contact_0313`.`pager_pin`, `s_contact_0313`.`pager_type_cd`, `s_contact_0313`.`password`, `s_contact_0313`.`paternal_last_name`, `s_contact_0313`.`per_title`, `s_contact_0313`.`per_title_suffix`, `s_contact_0313`.`place_of_birth`, `s_contact_0313`.`postn_cd`, `s_contact_0313`.`practice_type`, `s_contact_0313`.`pref_comm_media_cd`, `s_contact_0313`.`pref_comm_meth_cd`, `s_contact_0313`.`pref_lang_id`, `s_contact_0313`.`pref_locale_id`, `s_contact_0313`.`pref_sale_dlr_id`, `s_contact_0313`.`presence_uri`, `s_contact_0313`.`privacy_cd`, `s_contact_0313`.`pr_act_id`, `s_contact_0313`.`pr_affl_id`, `s_contact_0313`.`pr_alt_ph_num_id`, `s_contact_0313`.`pr_asset_id`, `s_contact_0313`.`pr_bl_per_addr_id`, `s_contact_0313`.`pr_client_ou_id`, `s_contact_0313`.`pr_comm_lang_id`, `s_contact_0313`.`pr_con_addr_id`, `s_contact_0313`.`pr_cst_accnt_id`, `s_contact_0313`.`pr_cti_cfg_id`, `s_contact_0313`.`pr_dept_ou_id`, `s_contact_0313`.`pr_drvr_license_id`, `s_contact_0313`.`pr_email_addr_id`, `s_contact_0313`.`pr_facility_id`, `s_contact_0313`.`pr_grp_ou_id`, `s_contact_0313`.`pr_held_postn_id`, `s_contact_0313`.`pr_image_id`, `s_contact_0313`.`pr_indust_id`, `s_contact_0313`.`pr_mkt_seg_id`, `s_contact_0313`.`pr_note_id`, `s_contact_0313`.`pr_opty_id`, `s_contact_0313`.`pr_ou_addr_id`, `s_contact_0313`.`pr_per_addr_id`, `s_contact_0313`.`pr_per_pay_prfl_id`, `s_contact_0313`.`pr_phone_id`, `s_contact_0313`.`pr_postn_id`, `s_contact_0313`.`pr_prod_id`, `s_contact_0313`.`pr_prod_ln_id`, `s_contact_0313`.`pr_region_id`, `s_contact_0313`.`pr_resp_id`, `s_contact_0313`.`pr_security_id`, `s_contact_0313`.`pr_sh_per_addr_id`, `s_contact_0313`.`pr_specialty_id`, `s_contact_0313`.`pr_state_lic_id`, `s_contact_0313`.`pr_sync_user_id`, `s_contact_0313`.`pr_terr_id`, `s_contact_0313`.`pr_userrole_id`, `s_contact_0313`.`race`, `s_contact_0313`.`rating`, `s_contact_0313`.`region_id`, `s_contact_0313`.`regl_stat_cd`, `s_contact_0313`.`reliability_cd`, `s_contact_0313`.`resident_stat_cd`, `s_contact_0313`.`right_eye_clr_cd`, `s_contact_0313`.`route`, `s_contact_0313`.`sec_answr`, `s_contact_0313`.`sec_quest_cd`, `s_contact_0313`.`sex_mf`, `s_contact_0313`.`soc_security_num`, `s_contact_0313`.`spouse_last_name`, `s_contact_0313`.`src_id`, `s_contact_0313`.`status_cd`, `s_contact_0313`.`stat_reason_cd`, `s_contact_0313`.`stock_portfolio`, `s_contact_0313`.`sub_spec_id`, `s_contact_0313`.`svc_branch_id`, `s_contact_0313`.`timezone_id`, `s_contact_0313`.`tmzone_cd`, `s_contact_0313`.`weathr_loc_pref`, `s_contact_0313`.`web_region_id`, `s_contact_0313`.`weight`, `s_contact_0313`.`weight_uom_cd`, `s_contact_0313`.`work_ph_num`, `s_contact_0313`.`x_suppress_notifications`, `s_contact_0313`.`x_unearned_income1`, `s_contact_0313`.`x_unearned_income2`, `s_contact_0313`.`x_unearned_income3`, `s_contact_0313`.`x_unearned_income_date`, `s_contact_0313`.`x_unearned_income_year`, `s_contact_0313`.`x_current_income`, `s_contact_0313`.`x_personal_interest`, `s_contact_0313`.`x_sensitive_contact`, `s_contact_0313`.`x_notional_ben_inc_asses`, `s_contact_0313`.`x_dob_cisverified`, `s_contact_0313`.`x_allow_status`, `s_contact_0313`.`x_hmrc_deo_sourced_date`, `s_contact_0313`.`effective_from_dt`, `s_contact_0313`.`effective_to_dt`, `s_contact_0313`.`current_flg`, `s_contact_0313`.`load_dt`, `s_contact_0313`.`etl_proc_wid`, `s_contact_0313`.`change_flg`, `s_contact_0313`.`x_tam_status`, `s_contact_0313`.`x_bankrupt_date`, `s_contact_0313`.`x_bankrupt_status`, `s_contact_0313`.`x_point_of_contact`, `s_contact_0313`.`x_primary_contact_flg`, `s_contact_0313`.`x_seq_num`, `s_contact_0313`.`x_spec_req_id`, `s_contact_0313`.`x_work_ph_ext`, `s_contact_0313`.`load_date`, `s_contact_0313`.`business_date`,


row_number () over (partition by `s_contact_0313`.`row_id` order by `s_contact_0313`.`business_date` desc) as `rownum`
from `siebel_base.s_contact) `A`
where `a`.`rownum` = 1)
`con`
left outer join
(
select 
`s_contact_bu`.`contact_id`,`s_contact_bu`.`bu_id`,`s_contact_bu`.`x_scin_num`
from `siebel_base`.`s_contact_bu`
where `s_contact_bu`.`x_scin_num` is not null 
)`bu` on 
`con`.`row_id`=`bu`.`contact_id` and `con`.`bu_id`=`bu`.`bu_id` 
where `con`.`current_flg`='Y'







insert overwrite table cap_mi.service_request_event_fact partition(load_date,business_date)
select
p.*,c.*,


if(a.sr_stat_id='Closed' and a.sr_due_date is not null and a.sr_end_date is not null,1,0) as sr_event_clearance_ind,

if(a.sr_version_number=0 and a.sr_due_date is not null and to_date(a.sr_created_date)=to_date(a.sr_start_date),1,0) as sr_event_intake_ind
,a.*
from
cap_mi.v_service_request_dim a
left join cap_mi.v_contact_dim p ON a.OWNER_EMP_ID=p.contact_id
left join cap_mi.v_case_dim c ON a.sr_case_id=c.case_id;
