case when set_fact.sr_event_clearance_ind = '1' then 

case when
( datediff(to_date(set_fact.sr_end_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.sr_end_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.sr_end_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_end_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
- case when cast(set_fact.sr_start_date as date) <= cast('2018-08-06' as date) and cast(set_fact.sr_end_date as date) >= cast('2018-08-06' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2018-08-27' as date) and cast(set_fact.sr_end_date as date) >= cast('2018-08-27' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2018-12-24' as date) and cast(set_fact.sr_end_date as date) >= cast('2018-12-24' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2018-12-25' as date) and cast(set_fact.sr_end_date as date) >= cast('2018-12-25' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2018-12-26' as date) and cast(set_fact.sr_end_date as date) >= cast('2018-12-26' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2019-01-01' as date) and cast(set_fact.sr_end_date as date) >= cast('2019-01-01' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2019-02-01' as date) and cast(set_fact.sr_end_date as date) >= cast('2019-02-01' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2019-03-18' as date) and cast(set_fact.sr_end_date as date) >= cast('2019-03-18' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2019-04-19' as date) and cast(set_fact.sr_end_date as date) >= cast('2019-04-19' as date) then 1 else 0 end ) < 0 then 0
else
datediff(to_date(set_fact.sr_end_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.sr_end_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.sr_end_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_end_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
- case when cast(set_fact.sr_start_date as date) <= cast('2018-08-06' as date) and cast(set_fact.sr_end_date as date) >= cast('2018-08-06' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2018-08-27' as date) and cast(set_fact.sr_end_date as date) >= cast('2018-08-27' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2018-12-24' as date) and cast(set_fact.sr_end_date as date) >= cast('2018-12-24' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2018-12-25' as date) and cast(set_fact.sr_end_date as date) >= cast('2018-12-25' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2018-12-26' as date) and cast(set_fact.sr_end_date as date) >= cast('2018-12-26' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2019-01-01' as date) and cast(set_fact.sr_end_date as date) >= cast('2019-01-01' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2019-02-01' as date) and cast(set_fact.sr_end_date as date) >= cast('2019-02-01' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2019-03-18' as date) and cast(set_fact.sr_end_date as date) >= cast('2019-03-18' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2019-04-19' as date) and cast(set_fact.sr_end_date as date) >= cast('2019-04-19' as date) then 1 else 0 end 
end



case when
(datediff(to_date(set_fact.business_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.business_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.business_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.business_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
- case when cast(set_fact.sr_start_date as date) <= cast('2018-08-06' as date) and cast(set_fact.business_date as date) >= cast('2018-08-06' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2018-08-27' as date) and cast(set_fact.business_date as date) >= cast('2018-08-27' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2018-12-24' as date) and cast(set_fact.business_date as date) >= cast('2018-12-24' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2018-12-25' as date) and cast(set_fact.business_date as date) >= cast('2018-12-25' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2018-12-26' as date) and cast(set_fact.business_date as date) >= cast('2018-12-26' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2019-01-01' as date) and cast(set_fact.business_date as date) >= cast('2019-01-01' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2019-02-01' as date) and cast(set_fact.business_date as date) >= cast('2019-02-01' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2019-03-18' as date) and cast(set_fact.business_date as date) >= cast('2019-03-18' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2019-04-19' as date) and cast(set_fact.business_date as date) >= cast('2019-04-19' as date) then 1 else 0 end ) < 0 then 0
else
datediff(to_date(set_fact.business_date),to_date(set_fact.sr_start_date)) 
- ( 2 * (( (YEAR(set_fact.business_date) - YEAR(set_fact.sr_start_date)) * 52) + (WEEKOFYEAR(set_fact.business_date) - WEEKOFYEAR(set_fact.sr_start_date) )) )
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.business_date, 'YYYY-MM-DD'), 'EEE')) = 'SUN' then 1 else 0 end 
- case when upper(FROM_UNIXTIME(UNIX_TIMESTAMP(set_fact.sr_start_date, 'YYYY-MM-DD'), 'EEE')) = 'SAT' then 1 else 0 end 
- case when cast(set_fact.sr_start_date as date) <= cast('2018-08-06' as date) and cast(set_fact.business_date as date) >= cast('2018-08-06' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2018-08-27' as date) and cast(set_fact.business_date as date) >= cast('2018-08-27' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2018-12-24' as date) and cast(set_fact.business_date as date) >= cast('2018-12-24' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2018-12-25' as date) and cast(set_fact.business_date as date) >= cast('2018-12-25' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2018-12-26' as date) and cast(set_fact.business_date as date) >= cast('2018-12-26' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2019-01-01' as date) and cast(set_fact.business_date as date) >= cast('2019-01-01' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2019-02-01' as date) and cast(set_fact.business_date as date) >= cast('2019-02-01' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2019-03-18' as date) and cast(set_fact.business_date as date) >= cast('2019-03-18' as date) then 1 else 0 end
- case when cast(set_fact.sr_start_date as date) <= cast('2019-04-19' as date) and cast(set_fact.business_date as date) >= cast('2019-04-19' as date) then 1 else 0 end 
end