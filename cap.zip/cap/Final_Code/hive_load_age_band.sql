
drop table if exists ${hivevar:dbName}.tmp_age_band_int;


create temporary table ${hivevar:dbName}.tmp_age_band_int as
select tmp.total_sla, tmp.band1 as no_of_days, 'band 1' as band, tmp.age_band_type
from ${hivevar:dbName}.tmp_age_band tmp

union all
select  tmp.total_sla, tmp.band2 as no_of_days, 'band 2' as band, tmp.age_band_type
from ${hivevar:dbName}.tmp_age_band tmp

union all
select  tmp.total_sla, tmp.band3 as no_of_days, 'band 3' as band, tmp.age_band_type
from ${hivevar:dbName}.tmp_age_band tmp

union all
select  tmp.total_sla, tmp.band4 as no_of_days, 'band 4' as band, tmp.age_band_type
from ${hivevar:dbName}.tmp_age_band tmp

union all
select  tmp.total_sla, tmp.band5 as no_of_days, 'band 5' as band, tmp.age_band_type
from ${hivevar:dbName}.tmp_age_band tmp

union all
select  tmp.total_sla, tmp.band6 as no_of_days, 'band 6' as band, tmp.age_band_type
from ${hivevar:dbName}.tmp_age_band tmp

union all
select  tmp.total_sla, tmp.band7 as no_of_days, 'band 7' as band, tmp.age_band_type
from ${hivevar:dbName}.tmp_age_band tmp

union all
select  tmp.total_sla, cast(cast(trim(substr(tmp.band8,2,3)) as int) +1 as string) as no_of_days, 'band 8' as band, tmp.age_band_type
from ${hivevar:dbName}.tmp_age_band tmp;


create table ${hivevar:dbName}.age_band as 
select 
b.total_sla, 
b.band, 
case when b.band ='band 1' then  0 else  b.no_of_days end as start_day, 
case when a.no_of_days is null then 999999
else a.no_of_days end as end_day
from 
(select  
total_sla,
no_of_days,
cast(substring(band,6,1) as int) bandint,
band,
age_band_type
from ${hivevar:dbName}.tmp_age_band_int 
) b
left join 
(select 
total_sla,
no_of_days,
cast(substring(band,6,1) as int) bandint,
band,
age_band_type
from ${hivevar:dbName}.tmp_age_band_int 
) a
on a.total_sla = b.total_sla and a.bandint = b.bandint + 1;
