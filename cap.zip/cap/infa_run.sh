cd /opt/informatica/10.2.1/server/bin
infacmd ms RunMapping -dn dwhacceldom -sn dwh_dis -un satyas.dasmohp -pd SatyasDasmohp -a Application_m_test_param_sat_s_case_a -m m_test_param_sat_s_case -pf /home/satyas.dasmohp@SDP.LOCAL/scripts/param_file.xml

