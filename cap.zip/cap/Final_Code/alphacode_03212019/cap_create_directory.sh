hdfsDIR=$1
#/user/hive/warehouse

#HDFS data directories setup for raw and base layer database

hadoop fs -mkdir -p ${hdfsDIR}/bancs
hadoop fs -mkdir -p ${hdfsDIR}/bancs/raw.db
hadoop fs -mkdir -p ${hdfsDIR}/bancs/base.db
hadoop fs -mkdir -p ${hdfsDIR}/siebel
hadoop fs -mkdir -p ${hdfsDIR}/siebel/raw.db
hadoop fs -mkdir -p ${hdfsDIR}/siebel/base.db


#HDFS data directories setup for tables in raw layer database
hadoop fs -mkdir -p ${hdfsDIR}/siebel/raw.db/s_contact
hadoop fs -mkdir -p ${hdfsDIR}/siebel/raw.db/s_contact_bu
hadoop fs -mkdir -p ${hdfsDIR}/siebel/raw.db/s_postn
hadoop fs -mkdir -p ${hdfsDIR}/siebel/raw.db/s_org_ext
hadoop fs -mkdir -p ${hdfsDIR}/siebel/raw.db/s_case
hadoop fs -mkdir -p ${hdfsDIR}/siebel/raw.db/s_user
hadoop fs -mkdir -p ${hdfsDIR}/siebel/raw.db/cx_intraday_s_srv_req


#HDFS data directories setup for tables in base layer database
hadoop fs -mkdir -p ${hdfsDIR}/siebel/base.db/s_contact
hadoop fs -mkdir -p ${hdfsDIR}/siebel/base.db/s_contact_bu
hadoop fs -mkdir -p ${hdfsDIR}/siebel/base.db/s_postn
hadoop fs -mkdir -p ${hdfsDIR}/siebel/base.db/s_org_ext
hadoop fs -mkdir -p ${hdfsDIR}/siebel/base.db/s_case
hadoop fs -mkdir -p ${hdfsDIR}/siebel/base.db/s_user
hadoop fs -mkdir -p ${hdfsDIR}/siebel/base.db/cx_intraday_s_srv_req
