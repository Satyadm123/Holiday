from pyspark import SparkConf,SparkContext
from pyspark.sql import HiveContext, SQLContext
import sys
from operator import add

#spark-submit --num-executors 5 --executor-cores 3 --master yarn-client --executor-memory 10g --driver-memory 4g spark_test.py

def main():
    conf = SparkConf().setMaster('yarn-cluster')
    conf = conf.setAppName('test Maksud')
    conf = conf.set ("spark.core.connection.ack.wait.timeout","600")
    sc = SparkContext(conf=conf)
    print "Maksud"
    df = SQLContext.sql("select srv_dim.service_request_id ,srv_dim.service_request_number ,srv_dim.service_request_start_date ,srv_dim.service_request_start_time,srv_dim.service_request_end_date , srv_dim.service_request_end_time , srv_dim.service_request_due_date , srv_dim.service_request_process , srv_dim.service_request_area , srv_dim.service_request_sub_area ,srv_dim.service_request_reason , srv_dim.service_request_resolution_code ,srv_dim.service_next_action_due_date ,srv_dim.service_request_source ,srv_dim.service_request_case_id ,srv_dim.service_request_owner_employee_id ,srv_dim.service_request_created_date ,srv_dim.service_request_updated_date ,srv_dim.service_request_version_number , srv_dim.service_request_status , case_dim.case_id, case_dim.case_number, case_dim.case_master_case_number,case_dim.case_created_date,	case_dim.case_update_date,case_dim.case_version_number,srv_dim.service_request_load_date ,srv_dim.service_request_business_date from cap_mi_2012.v_service_request_dim srv_dim left outer join cap_mi_2012.v_case_dim case_dim on srv_dim.service_request_case_id = case_dim.case_id;");
    print df.count()

if __name__ == "__main__":
    main()
	
