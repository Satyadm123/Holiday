CREATE DATABASE IF NOT EXISTS ${hivevar:dbName} COMMENT 'cap_mi_2012 database' LOCATION '${hivevar:hdfsDIR}';

CREATE VIEW ${hivevar:dbName}.v_service_request_dim AS SELECT 
	sr.cx_row_id sr_id,
	sr.sr_num sr_number,
	sr.ins_product sr_process,
	sr.sr_area sr_area,
	sr.sr_sub_area sr_sub_area,
	sr.created sr_start_date,
	sr.created sr_start_time,
	sr.act_close_dt sr_end_date,
	sr.act_close_dt sr_end_time,
	sr.reason_cd sr_reason,
	sr.cem_due_dt sr_due_date,
	sr.resolution_cd sr_resolution_code,
	sr.sr_stat_id sr_status,
	sr.sr_sub_stat_id sr_sub_status,
	sr.x_next_act_date sr_next_action_due_date,
	sr.sr_subtype_cd sr_source,
	sr.case_id sr_case_id,
	sr.owner_emp_id sr_owner_employee_id,
	sr.act_open_dt sr_created_date,
	sr.last_upd sr_updated_date,
	sr.modification_num sr_version_number,
	sr.x_uniq_ref_num sr_x_uniq_ref_num,
	sr.load_date load_date,
	sr.business_date business_date
FROM ${hivevar:dbName_base}.cx_intraday_s_srv_req sr 
WHERE sr.load_date != '2019-02-21';

CREATE VIEW ${hivevar:dbName}.v_case_dim AS select
    case_a.row_id as case_id,
    case_a.case_num as case_number,
	contact.case_num as case_master_case_number,
	case_a.created as case_created_date,
	case_a.last_upd as case_update_date,
	case_a.modification_num as case_version_number
from
(
select `a`.`row_id` as `row_id` ,`a`.`case_num` as `case_num`, `a`.`created` as `created`, `a`.`last_upd` as `last_upd`,`a`.`modification_num` as `modification_num` from
(select row_number () over (partition by `s_case_0313`.`row_id` order by `s_case_0313`.`business_date` desc) as `row_num`,
`s_case_0313`.`row_id`,`s_case_0313`.`case_num`,`s_case_0313`.`created`,`s_case_0313`.`last_upd`,`s_case_0313`.`modification_num`
from ${hivevar:dbName_base}.`s_case_0313`) `A`
where `a`.`row_num` =1)  `case_a`
left outer join 
(
select `a1`.`case_num`, `a1`.`row_id`, `b1`.`mstr_case_id` from 
(select distinct `a`.`case_num` as `case_num` ,`a`.`row_id` as `row_id` from  
(
select 
row_number () over (partition by `s_case_0313`.`row_id` order by `s_case_0313`.`business_date` desc) as `row_num`,
`s_case_0313`.`case_num`, `s_case_0313`.`row_id` from ${hivevar:dbName_base}.`S_CASE_0313`) `A`
where `a`.`row_num` = 1) `A1`
inner join
(
select  `b`.`mstr_case_id` from  
(
select 
row_number () over (partition by `s_contact_0313`.`row_id` order by `s_contact_0313`.`business_date` desc) as `row_num`,
`s_contact_0313`.`mstr_case_id` from ${hivevar:dbName_base}.`S_CONTACT_0313`) `B`
where `b`.`row_num` = 1) `B1`

on  `a1`.`row_id`= `b1`.`mstr_case_id`
) `contact`

on `case_a`.`row_id`=`contact`.`row_id` ;

CREATE VIEW `v_contact_dim` AS select
`con`.`row_id` as `contact_id`,
`bu`.`x_scin_num` as `contact_scin`,
`con`.`created` as `contact_created_date`, 
`con`.`last_upd` as `contact_update_date`,
`con`.`modification_num` as `contact_version_number`,
`con`.`pr_held_postn_id` as `contact_position`
from
(select `a`.`row_wid`, `a`.`row_id`, `a`.`created`, `a`.`created_by`, `a`.`last_upd`, `a`.`last_upd_by`, `a`.`dcking_num`, `a`.`modification_num`, `a`.`conflict_id`, `a`.`par_row_id`, 
`a`.`active_flg`, `a`.`bu_id`, `a`.`court_pay_flg`, `a`.`disa_cleanse_flg`, `a`.`disp_img_auth_flg`, `a`.`email_sr_upd_flg`, `a`.`emp_flg`, `a`.`fst_name`, `a`.`invstgtr_flg`, `a`.`last_name`, 
`a`.`person_uid`, `a`.`po_pay_flg`, `a`.`priv_flg`, `a`.`prospect_flg`, `a`.`ptshp_contact_flg`, `a`.`ptshp_key_con_flg`, `a`.`send_survey_flg`, `a`.`speaker_flg`, `a`.`suppress_email_flg`, 
`a`.`suppress_fax_flg`, `a`.`suspect_flg`, `a`.`susp_wtch_flg`, `a`.`agent_flg`, `a`.`enterprise_flag`, `a`.`member_flg`, `a`.`ok_to_sample_flg`, `a`.`provider_flg`, `a`.`pr_rep_dnrm_flg`, 
`a`.`pr_rep_manl_flg`, `a`.`pr_rep_sys_flg`, `a`.`send_fin_flg`, `a`.`send_news_flg`, `a`.`send_promotes_flg`, `a`.`suppress_call_flg`, `a`.`suppress_mail_flg`, `a`.`age`, `a`.`annl_incm_amt`, 
`a`.`annl_incm_exch_dt`, `a`.`asgn_dt`, `a`.`asgn_excld_flg2`, `a`.`asgn_required_flg2`, `a`.`asgn_usr_excld_flg`, `a`.`birth_dt`, `a`.`call_flg`, `a`.`consumer_flg`, `a`.`con_created_dt`,
 `a`.`credit_score`, `a`.`cust_end_dt`, `a`.`cust_since_dt`, `a`.`db_last_upd`, `a`.`death_dt`, `a`.`dedup_dataclnsd_dt`, `a`.`dedup_key_upd_dt`, `a`.`dedup_last_mtch_dt`, `a`.`hard_to_reach`,
 `a`.`inves_start_dt`, `a`.`inv_org_st_dt`, `a`.`last_credit_dt`, `a`.`latitude`, `a`.`longitude`, `a`.`lst_emladr_upd_ts`, `a`.`mgmnt_flg`, `a`.`num_hard_bnce`, `a`.`num_soft_bnce`, 
 `a`.`seminar_invit_flg`, `a`.`active_cti_cfg_id`, `a`.`active_teleset_id`, `a`.`aia_integ_id`, `a`.`alias_name`, `a`.`alt_email_addr`, `a`.`alt_email_loc_cd`, `a`.`alt_ph_num`, 
 `a`.`annl_incm_curcy_cd`, `a`.`approval_status_cd`, `a`.`area_id`, `a`.`asst_ph_num`, `a`.`call_frequency`, `a`.`cell_ph_num`, `a`.`citizenship_cd`, `a`.`comments`, `a`.`complexion_cd`, 
 `a`.`con_asst_name`, `a`.`con_asst_per_id`, `a`.`con_cd`, `a`.`con_exper_cd`, `a`.`con_image_id`, `a`.`con_influnc_id`, `a`.`con_manager_name`, `a`.`con_manager_per_id`, `a`.`corp_ptrnl_lstname`, 
 `a`.`country_template`, `a`.`creator_login`, `a`.`credit_agency`, `a`.`csn`, `a`.`curr_pri_lst_id`, `a`.`cust_stat_cd`, `a`.`cust_value_cd`, `a`.`db_last_upd_src`, `a`.`decision_type_cd`,
 `a`.`dedup_token`, `a`.`degree`, `a`.`dflt_order_proc_cd`, `a`.`email_addr`, `a`.`email_loc_cd`, `a`.`email_status_cd`, `a`.`emplmnt_stat_cd`, `a`.`emp_id`, `a`.`emp_num`, `a`.`emp_work_loc_name`, 
 `a`.`ethnicity_cd`, `a`.`eye_color`, `a`.`fax_ph_num`, `a`.`furi_ptrnl_lstname`, `a`.`hair_color`, `a`.`height`, `a`.`height_uom_cd`, `a`.`home_ph_num`, `a`.`indust_id`, `a`.`integration_id`, 
 `a`.`job_title`, `a`.`left_eye_clr_cd`, `a`.`login`, `a`.`maiden_name`, `a`.`marital_stat_cd`, `a`.`med_spec_id`, `a`.`mid_name`, `a`.`mother_maiden_name`, `a`.`mstr_case_id`, `a`.`nationality`, 
 `a`.`new_user_resp_name`, `a`.`nick_name`, `a`.`occupation`, `a`.`ou_id`, `a`.`ou_mail_stop`, `a`.`owner_login`, `a`.`owner_per_id`, `a`.`pager_company_id`, `a`.`pager_num`, `a`.`pager_ph_num`, 
 `a`.`pager_pin`, `a`.`pager_type_cd`, `a`.`password`, `a`.`paternal_last_name`, `a`.`per_title`, `a`.`per_title_suffix`, `a`.`place_of_birth`, `a`.`postn_cd`, `a`.`practice_type`, 
 `a`.`pref_comm_media_cd`, `a`.`pref_comm_meth_cd`, `a`.`pref_lang_id`, `a`.`pref_locale_id`, `a`.`pref_sale_dlr_id`, `a`.`presence_uri`, `a`.`privacy_cd`, `a`.`pr_act_id`, `a`.`pr_affl_id`, 
 `a`.`pr_alt_ph_num_id`, `a`.`pr_asset_id`, `a`.`pr_bl_per_addr_id`, `a`.`pr_client_ou_id`, `a`.`pr_comm_lang_id`, `a`.`pr_con_addr_id`, `a`.`pr_cst_accnt_id`, `a`.`pr_cti_cfg_id`, 
 `a`.`pr_dept_ou_id`, `a`.`pr_drvr_license_id`, `a`.`pr_email_addr_id`, `a`.`pr_facility_id`, `a`.`pr_grp_ou_id`, `a`.`pr_held_postn_id`, `a`.`pr_image_id`, `a`.`pr_indust_id`, 
 `a`.`pr_mkt_seg_id`, `a`.`pr_note_id`, `a`.`pr_opty_id`, `a`.`pr_ou_addr_id`, `a`.`pr_per_addr_id`, `a`.`pr_per_pay_prfl_id`, `a`.`pr_phone_id`, `a`.`pr_postn_id`, `a`.`pr_prod_id`, 
 `a`.`pr_prod_ln_id`, `a`.`pr_region_id`, `a`.`pr_resp_id`, `a`.`pr_security_id`, `a`.`pr_sh_per_addr_id`, `a`.`pr_specialty_id`, `a`.`pr_state_lic_id`, `a`.`pr_sync_user_id`, `a`.`pr_terr_id`, 
 `a`.`pr_userrole_id`, `a`.`race`, `a`.`rating`, `a`.`region_id`, `a`.`regl_stat_cd`, `a`.`reliability_cd`, `a`.`resident_stat_cd`, `a`.`right_eye_clr_cd`, `a`.`route`, `a`.`sec_answr`, 
 `a`.`sec_quest_cd`, `a`.`sex_mf`, `a`.`soc_security_num`, `a`.`spouse_last_name`, `a`.`src_id`, `a`.`status_cd`, `a`.`stat_reason_cd`, `a`.`stock_portfolio`, `a`.`sub_spec_id`, `a`.`svc_branch_id`,
 `a`.`timezone_id`, `a`.`tmzone_cd`, `a`.`weathr_loc_pref`, `a`.`web_region_id`, `a`.`weight`, `a`.`weight_uom_cd`, `a`.`work_ph_num`, `a`.`x_suppress_notifications`, `a`.`x_unearned_income1`, 
 `a`.`x_unearned_income2`, `a`.`x_unearned_income3`, `a`.`x_unearned_income_date`, `a`.`x_unearned_income_year`, `a`.`x_current_income`, `a`.`x_personal_interest`, `a`.`x_sensitive_contact`, 
 `a`.`x_notional_ben_inc_asses`, `a`.`x_dob_cisverified`, `a`.`x_allow_status`, `a`.`x_hmrc_deo_sourced_date`, `a`.`effective_from_dt`, `a`.`effective_to_dt`, `a`.`current_flg`, `a`.`load_dt`, 
 `a`.`etl_proc_wid`, `a`.`change_flg`, `a`.`x_tam_status`, `a`.`x_bankrupt_date`, `a`.`x_bankrupt_status`, `a`.`x_point_of_contact`, `a`.`x_primary_contact_flg`, `a`.`x_seq_num`, 
 `a`.`x_spec_req_id`, `a`.`x_work_ph_ext`, `a`.`load_date`, `a`.`business_date`, `a`.`rownum` from 
(select `s_contact`.`row_wid`, `s_contact`.`row_id`, `s_contact`.`created`, `s_contact`.`created_by`, `s_contact`.`last_upd`, `s_contact`.`last_upd_by`, `s_contact`.`dcking_num`, 
`s_contact`.`modification_num`, `s_contact`.`conflict_id`, `s_contact`.`par_row_id`, `s_contact`.`active_flg`, `s_contact`.`bu_id`, `s_contact`.`court_pay_flg`, `s_contact`.`disa_cleanse_flg`, 
`s_contact`.`disp_img_auth_flg`, `s_contact`.`email_sr_upd_flg`, `s_contact`.`emp_flg`, `s_contact`.`fst_name`, `s_contact`.`invstgtr_flg`, `s_contact`.`last_name`, `s_contact`.`person_uid`, 
`s_contact`.`po_pay_flg`, `s_contact`.`priv_flg`, `s_contact`.`prospect_flg`, `s_contact`.`ptshp_contact_flg`, `s_contact`.`ptshp_key_con_flg`, `s_contact`.`send_survey_flg`, 
`s_contact`.`speaker_flg`, `s_contact`.`suppress_email_flg`, `s_contact`.`suppress_fax_flg`, `s_contact`.`suspect_flg`, `s_contact`.`susp_wtch_flg`, `s_contact`.`agent_flg`, 
`s_contact`.`enterprise_flag`, `s_contact`.`member_flg`, `s_contact`.`ok_to_sample_flg`, `s_contact`.`provider_flg`, `s_contact`.`pr_rep_dnrm_flg`, `s_contact`.`pr_rep_manl_flg`, 
`s_contact`.`pr_rep_sys_flg`, `s_contact`.`send_fin_flg`, `s_contact`.`send_news_flg`, `s_contact`.`send_promotes_flg`, `s_contact`.`suppress_call_flg`, `s_contact`.`suppress_mail_flg`,
 `s_contact`.`age`, `s_contact`.`annl_incm_amt`, `s_contact`.`annl_incm_exch_dt`, `s_contact`.`asgn_dt`, `s_contact`.`asgn_excld_flg2`, `s_contact`.`asgn_required_flg2`, 
 `s_contact`.`asgn_usr_excld_flg`, `s_contact`.`birth_dt`, `s_contact`.`call_flg`, `s_contact`.`consumer_flg`, `s_contact`.`con_created_dt`, `s_contact`.`credit_score`, `s_contact`.`cust_end_dt`, 
 `s_contact`.`cust_since_dt`, `s_contact`.`db_last_upd`, `s_contact`.`death_dt`, `s_contact`.`dedup_dataclnsd_dt`, `s_contact`.`dedup_key_upd_dt`, `s_contact`.`dedup_last_mtch_dt`, 
 `s_contact`.`hard_to_reach`, `s_contact`.`inves_start_dt`, `s_contact`.`inv_org_st_dt`, `s_contact`.`last_credit_dt`, `s_contact`.`latitude`, `s_contact`.`longitude`,
 `s_contact`.`lst_emladr_upd_ts`, `s_contact`.`mgmnt_flg`, `s_contact`.`num_hard_bnce`, `s_contact`.`num_soft_bnce`, `s_contact`.`seminar_invit_flg`, `s_contact`.`active_cti_cfg_id`,
 `s_contact`.`active_teleset_id`, `s_contact`.`aia_integ_id`, `s_contact`.`alias_name`, `s_contact`.`alt_email_addr`, `s_contact`.`alt_email_loc_cd`, `s_contact`.`alt_ph_num`, 
 `s_contact`.`annl_incm_curcy_cd`, `s_contact`.`approval_status_cd`, `s_contact`.`area_id`, `s_contact`.`asst_ph_num`, `s_contact`.`call_frequency`, `s_contact`.`cell_ph_num`, 
 `s_contact`.`citizenship_cd`, `s_contact`.`comments`, `s_contact`.`complexion_cd`, `s_contact`.`con_asst_name`, `s_contact`.`con_asst_per_id`, `s_contact`.`con_cd`, `s_contact`.`con_exper_cd`, 
 `s_contact`.`con_image_id`, `s_contact`.`con_influnc_id`, `s_contact`.`con_manager_name`, `s_contact`.`con_manager_per_id`, `s_contact`.`corp_ptrnl_lstname`, `s_contact`.`country_template`, 
 `s_contact`.`creator_login`, `s_contact`.`credit_agency`, `s_contact`.`csn`, `s_contact`.`curr_pri_lst_id`, `s_contact`.`cust_stat_cd`, `s_contact`.`cust_value_cd`, `s_contact`.`db_last_upd_src`, 
 `s_contact`.`decision_type_cd`, `s_contact`.`dedup_token`, `s_contact`.`degree`, `s_contact`.`dflt_order_proc_cd`, `s_contact`.`email_addr`, `s_contact`.`email_loc_cd`, 
 `s_contact`.`email_status_cd`, `s_contact`.`emplmnt_stat_cd`, `s_contact`.`emp_id`, `s_contact`.`emp_num`, `s_contact`.`emp_work_loc_name`, `s_contact`.`ethnicity_cd`, `s_contact`.`eye_color`, 
 `s_contact`.`fax_ph_num`, `s_contact`.`furi_ptrnl_lstname`, `s_contact`.`hair_color`, `s_contact`.`height`, `s_contact`.`height_uom_cd`, `s_contact`.`home_ph_num`, `s_contact`.`indust_id`, 
 `s_contact`.`integration_id`, `s_contact`.`job_title`, `s_contact`.`left_eye_clr_cd`, `s_contact`.`login`, `s_contact`.`maiden_name`, `s_contact`.`marital_stat_cd`, `s_contact`.`med_spec_id`, 
 `s_contact`.`mid_name`, `s_contact`.`mother_maiden_name`, `s_contact`.`mstr_case_id`, `s_contact`.`nationality`, `s_contact`.`new_user_resp_name`, `s_contact`.`nick_name`, 
 `s_contact`.`occupation`, `s_contact`.`ou_id`, `s_contact`.`ou_mail_stop`, `s_contact`.`owner_login`, `s_contact`.`owner_per_id`, `s_contact`.`pager_company_id`, `s_contact`.`pager_num`, 
 `s_contact`.`pager_ph_num`, `s_contact`.`pager_pin`, `s_contact`.`pager_type_cd`, `s_contact`.`password`, `s_contact`.`paternal_last_name`, `s_contact`.`per_title`, `s_contact`.`per_title_suffix`, 
 `s_contact`.`place_of_birth`, `s_contact`.`postn_cd`, `s_contact`.`practice_type`, `s_contact`.`pref_comm_media_cd`, `s_contact`.`pref_comm_meth_cd`, `s_contact`.`pref_lang_id`, 
 `s_contact`.`pref_locale_id`, `s_contact`.`pref_sale_dlr_id`, `s_contact`.`presence_uri`, `s_contact`.`privacy_cd`, `s_contact`.`pr_act_id`, `s_contact`.`pr_affl_id`, 
 `s_contact`.`pr_alt_ph_num_id`, `s_contact`.`pr_asset_id`, `s_contact`.`pr_bl_per_addr_id`, `s_contact`.`pr_client_ou_id`, `s_contact`.`pr_comm_lang_id`, `s_contact`.`pr_con_addr_id`, 
 `s_contact`.`pr_cst_accnt_id`, `s_contact`.`pr_cti_cfg_id`, `s_contact`.`pr_dept_ou_id`, `s_contact`.`pr_drvr_license_id`, `s_contact`.`pr_email_addr_id`, `s_contact`.`pr_facility_id`, 
 `s_contact`.`pr_grp_ou_id`, `s_contact`.`pr_held_postn_id`, `s_contact`.`pr_image_id`, `s_contact`.`pr_indust_id`, `s_contact`.`pr_mkt_seg_id`, `s_contact`.`pr_note_id`, `s_contact`.`pr_opty_id`, 
 `s_contact`.`pr_ou_addr_id`, `s_contact`.`pr_per_addr_id`, `s_contact`.`pr_per_pay_prfl_id`, `s_contact`.`pr_phone_id`, `s_contact`.`pr_postn_id`, `s_contact`.`pr_prod_id`, 
 `s_contact`.`pr_prod_ln_id`, `s_contact`.`pr_region_id`, `s_contact`.`pr_resp_id`, `s_contact`.`pr_security_id`, `s_contact`.`pr_sh_per_addr_id`, `s_contact`.`pr_specialty_id`, 
 `s_contact`.`pr_state_lic_id`, `s_contact`.`pr_sync_user_id`, `s_contact`.`pr_terr_id`, `s_contact`.`pr_userrole_id`, `s_contact`.`race`, `s_contact`.`rating`, `s_contact`.`region_id`, 
 `s_contact`.`regl_stat_cd`, `s_contact`.`reliability_cd`, `s_contact`.`resident_stat_cd`, `s_contact`.`right_eye_clr_cd`, `s_contact`.`route`, `s_contact`.`sec_answr`, 
 `s_contact`.`sec_quest_cd`, `s_contact`.`sex_mf`, `s_contact`.`soc_security_num`, `s_contact`.`spouse_last_name`, `s_contact`.`src_id`, `s_contact`.`status_cd`, `s_contact`.`stat_reason_cd`, 
 `s_contact`.`stock_portfolio`, `s_contact`.`sub_spec_id`, `s_contact`.`svc_branch_id`, `s_contact`.`timezone_id`, `s_contact`.`tmzone_cd`, `s_contact`.`weathr_loc_pref`, 
 `s_contact`.`web_region_id`, `s_contact`.`weight`, `s_contact`.`weight_uom_cd`, `s_contact`.`work_ph_num`, `s_contact`.`x_suppress_notifications`, `s_contact`.`x_unearned_income1`, 
 `s_contact`.`x_unearned_income2`, `s_contact`.`x_unearned_income3`, `s_contact`.`x_unearned_income_date`, `s_contact`.`x_unearned_income_year`, `s_contact`.`x_current_income`, 
 `s_contact`.`x_personal_interest`, `s_contact`.`x_sensitive_contact`, `s_contact`.`x_notional_ben_inc_asses`, `s_contact`.`x_dob_cisverified`, `s_contact`.`x_allow_status`, 
 `s_contact`.`x_hmrc_deo_sourced_date`, `s_contact`.`effective_from_dt`, `s_contact`.`effective_to_dt`, `s_contact`.`current_flg`, `s_contact`.`load_dt`, `s_contact`.`etl_proc_wid`, 
 `s_contact`.`change_flg`, `s_contact`.`x_tam_status`, `s_contact`.`x_bankrupt_date`, `s_contact`.`x_bankrupt_status`, `s_contact`.`x_point_of_contact`, `s_contact`.`x_primary_contact_flg`, 
 `s_contact`.`x_seq_num`, `s_contact`.`x_spec_req_id`, `s_contact`.`x_work_ph_ext`, `s_contact`.`load_date`, `s_contact`.`business_date`,
 row_number () over (partition by `s_contact`.`row_id` order by `s_contact`.`business_date` desc) as `rownum`
from ${hivevar:dbName_base}.`S_CONTACT` where `s_contact`.`current_flg`='Y') `A`
where `a`.`rownum` = 1)
`con`
left outer join
(
select 
`s_contact_bu`.`contact_id`,`s_contact_bu`.`bu_id`,`s_contact_bu`.`x_scin_num`
from ${hivevar:dbName_base}.`s_contact_bu`
where `s_contact_bu`.`x_scin_num` is not null 
)`bu` on 
`con`.`row_id`=`bu`.`contact_id` and `con`.`bu_id`=`bu`.`bu_id` ;

CREATE VIEW `v_service_request_status_dim` AS SELECT `s`.`cx_row_id` `service_request_status_id`, 
CASE WHEN `l`.`name` IS NULL THEN `s`.`sr_stat_id` ELSE `l`.`name` END `service_request_status_name`, 
CASE WHEN `l`.`val` IS NULL THEN `s`.`sr_stat_id` ELSE `l`.`val` END `service_request_status_val`, 
'' `service_request_status_start_date`, 
'' `service_request_status_end_date`, 
`s`.`created` `service_request_status_created_date`, 
`s`.`last_upd` `service_request_status_update_date`, 
`s`.`modification_num` `service_request_status_version_number`,
'' `service_request_status_batch_number` 
FROM ${hivevar:dbName_base}.`cx_intraday_s_srv_req` `s` 
LEFT OUTER JOIN ${hivevar:dbName_base}.`s_lst_of_val` `l` ON (`s`.`sr_stat_id` = `l`.`val`) 
WHERE upper(trim(`l`.`type`)) = 'SR_STATUS';

CREATE VIEW `v_service_request_sub_status_dim` AS SELECT `s`.`cx_row_id` `service_request_sub_status_id`,
CASE WHEN `l`.`name` IS NULL THEN `s`.`sr_sub_stat_id` ELSE `l`.`name` END `service_request_sub_status_name`, 
CASE WHEN `l`.`val` IS NULL THEN `s`.`sr_sub_stat_id` ELSE `l`.`val` END `service_request_sub_status_val`, 
'' `service_request_sub_status_start_date`, 
'' `service_request_sub_status_end_date`,
`s`.`created` `service_request_sub_status_created_date`, 
`s`.`last_upd` `service_request_sub_status_update_date`, 
`s`.`modification_num` `service_request_sub_status_version_number`, 
'' `service_request_sub_status_batch_number` 
FROM ${hivevar:dbName_base}.`cx_intraday_s_srv_req` `s` 
LEFT OUTER JOIN 
(SELECT DISTINCT `s`.`name`, `s`.`val`, `s`.`type` 
FROM ${hivevar:dbName_base}.`s_lst_of_val` `s` WHERE upper(trim(`s`.`type`)) = 'SR_SUB_STATUS') `l` 
ON (`s`.`sr_sub_stat_id` = `l`.`val`);
