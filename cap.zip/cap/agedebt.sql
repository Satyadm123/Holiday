select 

nrp_acct bancs_account_number, 
basic_due_type liability_line_item_due_type_code ,
due_typ_desc liability_due_type_description ,
service_type liability_line_item_service_type ,

case when basic_due_type in ('0200','0210','0230','0240') then  '1' else
case when (basic_due_type = '0100' and service_type ='2') then  '1 'else
case when (basic_due_type = '0100' and service_type ='1') then  '3' else
case when basic_due_type in ('1502','1503','1504','1505','1506','1601','1701') then '2'  else
case when basic_due_type in ('1501','5010','5030','5060','5070','4200','4210','4230','4240') then '4' else
case when (basic_due_type ='4100' and service_type ='2') then '4' else
case when basic_due_type in  ('3200','3201','3202','3210','3211','3212','3230','3231','3232','3240','3241','3242','3300','3301','3302',
'3301','3302','3310;,;3311','3312','3400','3401','3402','3410','3411','3412') then '5'
end end end end end end end liability_due_type_summary_grouping,

month(nrp_due_date) liability_due_financial_month,

case 
when month(nrp_due_date) >= 4 then 
concat (cast(year(nrp_due_date) as string),'-',cast ( year(nrp_due_date) + 1 as string) ) else
case when month(nrp_due_date) <= 3 then 
concat (cast ( year(nrp_due_date) - 1 as string),'-',cast(year(nrp_due_date) as string)  )
end end liability_due_financial_year,

sum(due_amt ) value_of_liability_due_bancs_account_level_financial_month,
sum(paid_amt) value_of_liability_paid_bancs_account_level_financial_month,
sum(adj_due_amt) value_of_liability_adjusted_bancs_account_level_financial_month,
sum(amt_written_off) value_of_liability_written_off_bancs_account_level_financial_month

from 
bancs_base.lish
inner join bancs_base.dtcd
on bancs_base.lish.basic_due_type = bancs_base.dtcd.due_typ_cod
where 

stat not in ('20','08') 

and 

(
(case 
when month(nrp_due_date) >= 4 then 
concat (cast(year(nrp_due_date) as string),'-',cast ( year(nrp_due_date) + 1 as string) ) else
case when month(nrp_due_date) <= 3 then 
concat (cast ( year(nrp_due_date) - 1 as string),'-',cast(year(nrp_due_date) as string)  )
end end  =

case 
when month(current_timestamp()) >= 4 then 
concat (cast(year(current_timestamp()) - 1 as string),'-',cast ( year(current_timestamp())  as string) ) else
case when month(current_timestamp()) <= 3 then 
concat (cast ( year(current_timestamp()) - 2 as string),'-',cast(year(current_timestamp()) - 1 as string)  )
end end
)
or 
(
case 
when month(nrp_due_date) >= 4 then 
concat (cast(year(nrp_due_date) as string),'-',cast ( year(nrp_due_date) + 1 as string) ) else
case when month(nrp_due_date) <= 3 then 
concat (cast ( year(nrp_due_date) - 1 as string),'-',cast(year(nrp_due_date) as string)  )
end end  =
case 
when month(current_timestamp()) >= 4 then 
concat (cast(year(current_timestamp()) as string),'-',cast ( year(current_timestamp()) + 1  as string) ) else
case when month(current_timestamp()) <= 3 then 
concat (cast ( year(current_timestamp()) - 1 as string),'-',cast(year(current_timestamp())  as string)  )
end end
and  month(nrp_due_date) < month(current_timestamp())
)
)
group by
nrp_acct ,
basic_due_type ,
due_typ_desc,
service_type ,
case when basic_due_type in ('0200','0210','0230','0240') then  '1' else
case when (basic_due_type = '0100' and service_type ='2') then  '1 'else
case when (basic_due_type = '0100' and service_type ='1') then  '3' else
case when basic_due_type in ('1502','1503','1504','1505','1506','1601','1701') then '2'  else
case when basic_due_type in ('1501','5010','5030','5060','5070','4200','4210','4230','4240') then '4' else
case when (basic_due_type ='4100' and service_type ='2') then '4' else
case when basic_due_type in  ('3200','3201','3202','3210','3211','3212','3230','3231','3232','3240','3241','3242','3300','3301','3302',
'3301','3302','3310;,;3311','3312','3400','3401','3402','3410','3411','3412') then '5'
end end end end end end end ,
month(nrp_due_date) ,
case 
when month(nrp_due_date) >= 4 then 
concat (cast(year(nrp_due_date) as string),'-',cast ( year(nrp_due_date) + 1 as string) ) else
case when month(nrp_due_date) <= 3 then 
concat (cast ( year(nrp_due_date) - 1 as string),'-',cast(year(nrp_due_date) as string)  )
end end ;
