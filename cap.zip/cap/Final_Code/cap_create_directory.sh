hdfsDIR=$1
#hdfsDIR=/user/hive/warehouse

#HDFS data directories setup for raw and base layer database

hadoop fs -test -d ${hdfsDIR}/bancs11
if [ $? = 1 ] ; then 
	hadoop fs -mkdir -p ${hdfsDIR}/bancs11 ;
	echo "banc directory created" ;
else e
	echo "bancs directory already exist." ;
fi

hadoop fs -mkdir -p ${hdfsDIR}/bancs/raw.db
hadoop fs -mkdir -p ${hdfsDIR}/bancs/base.db
hadoop fs -mkdir -p ${hdfsDIR}/siebel
hadoop fs -mkdir -p ${hdfsDIR}/siebel/raw.db
hadoop fs -mkdir -p ${hdfsDIR}/siebel/base.db
hadoop fs -mkdir -p ${hdfsDIR}/cap
hadoop fs -mkdir -p ${hdfsDIR}/cap/mi_2012.db

#HDFS data directories setup for tables in raw layer database
hadoop fs -mkdir -p ${hdfsDIR}/siebel/raw.db/s_contact
hadoop fs -mkdir -p ${hdfsDIR}/siebel/raw.db/s_contact_bu
hadoop fs -mkdir -p ${hdfsDIR}/siebel/raw.db/s_postn
hadoop fs -mkdir -p ${hdfsDIR}/siebel/raw.db/s_org_ext
hadoop fs -mkdir -p ${hdfsDIR}/siebel/raw.db/s_case
hadoop fs -mkdir -p ${hdfsDIR}/siebel/raw.db/s_user
hadoop fs -mkdir -p ${hdfsDIR}/siebel/raw.db/cx_intraday_s_srv_req


#HDFS data directories setup for tables in base layer database
hadoop fs -mkdir -p ${hdfsDIR}/siebel/base.db/s_contact
hadoop fs -mkdir -p ${hdfsDIR}/siebel/base.db/s_contact_bu
hadoop fs -mkdir -p ${hdfsDIR}/siebel/base.db/s_postn
hadoop fs -mkdir -p ${hdfsDIR}/siebel/base.db/s_org_ext
hadoop fs -mkdir -p ${hdfsDIR}/siebel/base.db/s_case
hadoop fs -mkdir -p ${hdfsDIR}/siebel/base.db/s_user
hadoop fs -mkdir -p ${hdfsDIR}/siebel/base.db/cx_intraday_s_srv_req

#HDFS data directories setup for tables for flat struncture 
hadoop fs -mkdir -p ${hdfsDIR}/cap/mi_2012.db/service_request_event_fact_dim
