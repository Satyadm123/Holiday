select
datediff(to_date('2019-04-22'),to_date('2019-04-05')) ,

(floor((datediff(to_date('2019-04-22'),to_date('2019-04-05')) ) / 7) * 2),

case when
from_unixtime(unix_timestamp('2019-04-05','yyyy-MM-dd'),'u') - from_unixtime(unix_timestamp('2019-04-22','yyyy-MM-dd'),'u') in (1,2,3,4,5)
and from_unixtime(unix_timestamp('2019-04-22','yyyy-MM-dd'),'u') != 7  then 2 else 0 end ,

case when 
from_unixtime(unix_timestamp('2019-04-05','yyyy-MM-dd'),'u') != 7 and from_unixtime(unix_timestamp('2019-04-22','yyyy-MM-dd'),'u') = 7
then 1 else 0 end,

case when 
from_unixtime(unix_timestamp('2019-04-05','yyyy-MM-dd'),'u') = 7 and from_unixtime(unix_timestamp('2019-04-22','yyyy-MM-dd'),'u') != 7
then 1 else 0 end ;

case when 
from_unixtime(unix_timestamp('2019-04-05','yyyy-MM-dd'),'u') = 6 and from_unixtime(unix_timestamp('2019-04-22','yyyy-MM-dd'),'u') != 1
then 1 else 0 end ;







,

case when 
from_unixtime(unix_timestamp('2019-04-05','yyyy-MM-dd'),'u') != 6 and from_unixtime(unix_timestamp('2019-04-22','yyyy-MM-dd'),'u') = 6
then 1 else 0 end,

case when 
from_unixtime(unix_timestamp('2019-04-05','yyyy-MM-dd'),'u') = 6 and from_unixtime(unix_timestamp('2019-04-22','yyyy-MM-dd'),'u') != 6
then 1 else 0 end
;
